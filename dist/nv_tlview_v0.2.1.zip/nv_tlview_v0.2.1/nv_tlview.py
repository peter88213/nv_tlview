"""A timeline view plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_tlview
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys
import os
import locale
import gettext
import webbrowser
from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass
from datetime import datetime
import platform
from tkinter import ttk

from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


locale.setlocale(locale.LC_TIME, "")
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

from datetime import datetime
from datetime import timedelta


def from_timestamp(ts):
    return datetime.min + timedelta(seconds=ts)


def get_timestamp(dt):
    return int((dt - datetime.min).total_seconds() + 0.5)


def get_seconds(days, hours, minutes):
    seconds = 0
    if days:
        seconds = int(days) * 24 * 3600
    if hours:
        seconds += int(hours) * 3600
    if minutes:
        seconds += int(minutes) * 60
    return seconds

from tkinter import ttk
from datetime import datetime

import tkinter as tk


class TlCanvas(tk.Canvas):
    MAJOR_HEIGHT = 15
    MAJOR_WIDTH_MIN = 120
    MAJOR_WIDTH_MAX = 360
    SCALE_HEIGHT = MAJOR_HEIGHT + 5
    EVENT_DIST_Y = 35
    LABEL_DIST_X = 10
    MARK_HALF = 5

    SCALE_MIN = 10
    HOUR = 3600
    DAY = HOUR * 24
    YEAR = DAY * 365
    SCALE_MAX = YEAR * 5

    MIN_TIMESTAMP = get_timestamp(datetime.min)
    MAX_TIMESTAMP = get_timestamp(datetime.max)

    def __init__(self, master=None, cnf={}, **kw):
        super().__init__(master, cnf, **kw)
        self.events = {}
        self['background'] = 'black'

        if platform.system() == 'Linux':
            self.bind("<Control-Button-4>", self.on_control_mouse_wheel)
            self.bind("<Control-Button-5>", self.on_control_mouse_wheel)
            self.bind("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self.bind("<Shift-Button-5>", self.on_shift_mouse_wheel)
        else:
            self.bind("<Control-MouseWheel>", self.on_control_mouse_wheel)
            self.bind("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
        self.bind('<Configure>', self.draw_timeline)

        self._scale = self.SCALE_MIN
        self._startTimestamp = get_timestamp(datetime.now()) - self.HOUR

    @property
    def startTimestamp(self):
        return self._startTimestamp

    @startTimestamp.setter
    def startTimestamp(self, newVal):
        if newVal < self.MIN_TIMESTAMP:
            self._startTimestamp = self.MIN_TIMESTAMP
        elif newVal > self.MAX_TIMESTAMP:
            self._startTimestamp = self.MAX_TIMESTAMP
        else:
            self._startTimestamp = newVal
        self.draw_timeline()

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, newVal):
        if newVal < self.SCALE_MIN:
            self._scale = self.SCALE_MIN
        elif newVal > self.SCALE_MAX:
            self._scale = self.SCALE_MAX
        else:
            self._scale = newVal
        self.draw_timeline()

    def draw_timeline(self, event=None):
        self.delete("all")
        self.draw_scale()
        self.draw_events()

    def draw_scale(self):


        resolution = self.HOUR
        self.majorWidth = resolution / self.scale
        units = 0
        while self.majorWidth < self.MAJOR_WIDTH_MIN:
            resolution *= 2
            if units == 0 and resolution > self.DAY:
                resolution = self.DAY
                units = 1
            elif units == 1 and resolution > self.YEAR:
                resolution = self.YEAR
                units = 2
            self.majorWidth = resolution / self.scale

        tsOffset = resolution - self.startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / self.scale
        timestamp = self.startTimestamp + tsOffset

        xMax = self.winfo_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if units == 0:
                dtStr = f"{dt.strftime('%x')} {dt.hour:02}:{dt.minute:02}"
            elif units == 1:
                dtStr = f"{dt.strftime('%x')}"
            elif units == 2:
                dtStr = f"{dt.year}"
            self.create_line((xPos, 0), (xPos, self.MAJOR_HEIGHT), width=1, fill='white')
            self.create_text((xPos + 5, 2), text=dtStr, fill='white', anchor='nw')
            xPos += self.majorWidth
            timestamp += resolution

    def on_control_mouse_wheel(self, event):
        deltaScale = 1.5
        if event.num == 5 or event.delta == -120:
            self.scale *= deltaScale
        if event.num == 4 or event.delta == 120:
            self.scale /= deltaScale

    def on_shift_mouse_wheel(self, event):
        deltaOffset = self.scale / self.SCALE_MIN * self.majorWidth
        if event.num == 5 or event.delta == -120:
            self.startTimestamp += deltaOffset
        if event.num == 4 or event.delta == 120:
            self.startTimestamp -= deltaOffset

    def draw_events(self):
        yMax = (len(self.events) + 2) * self.EVENT_DIST_Y
        self.configure(scrollregion=(0, 0, 0, yMax))
        srtEvents = []
        for eventId in self.events:
            event = self.events[eventId]
            try:
                srtEvents.append(
                        (
                        get_timestamp(datetime.fromisoformat(f'{event.date} {event.time}')),
                        get_seconds(event.lastsDays, event.lastsHours, event.lastsMinutes),
                        event.title
                        )
                    )
            except:
                pass
        xEnd = 0
        yPos = self.EVENT_DIST_Y * 2
        labelEnd = 0
        for event in sorted(srtEvents):
            timestamp, duration, title = event
            xStart = (timestamp - self.startTimestamp) / self.scale
            dt = from_timestamp(timestamp)
            timeStr = f"{dt.strftime('%x')} {dt.hour:02}:{dt.minute:02}"

            if xStart > labelEnd:
                yPos = self.EVENT_DIST_Y * 2

            xEnd = (timestamp - self.startTimestamp + duration) / self.scale
            self.create_polygon(
                    (xStart, yPos - self.MARK_HALF),
                    (xStart - self.MARK_HALF, yPos),
                    (xStart, yPos + self.MARK_HALF),
                    (xEnd, yPos + self.MARK_HALF),
                    (xEnd + self.MARK_HALF, yPos),
                    (xEnd, yPos - self.MARK_HALF),
                    fill='red'
                )
            xLabel = xEnd + self.LABEL_DIST_X
            titleLabel = self.create_text((xLabel, yPos), text=title, fill='white', anchor='w')
            titleBounds = self.bbox(titleLabel)
            timeLabel = self.create_text(xLabel, titleBounds[3], text=timeStr, fill='lightgray', anchor='nw')
            timeBounds = self.bbox(timeLabel)
            labelEnd = max(titleBounds[2], timeBounds[2])
            yPos += self.EVENT_DIST_Y



class TlFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)

        self.scaleWindow = ttk.Frame(self)
        self.scaleWindow.pack(anchor='w', fill='x', expand=False)

        eventWindow = ttk.Frame(self)
        eventWindow.pack(fill='both', expand=True)
        self.eventCanvas = TlCanvas(eventWindow, bd=0, highlightthickness=0)
        self.eventCanvas.configure(yscrollcommand=scrollY.set)
        self.eventCanvas.pack(side='left', fill='both', expand=True)
        self.eventCanvas.xview_moveto(0)
        self.eventCanvas.yview_moveto(0)

        if platform.system() == 'Linux':
            self.eventCanvas.bind("<Button-4>", self.on_mouse_wheel)
            self.eventCanvas.bind("<Button-5>", self.on_mouse_wheel)
        else:
            self.eventCanvas.bind("<MouseWheel>", self.on_mouse_wheel)

    def yview(self, *args):
        self.eventCanvas.yview(*args)

    def xview(self, *args):
        self.eventCanvas.xview(*args)

    def yview_scroll(self, *args):
        self.eventCanvas.yview_scroll(*args)

    def on_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.yview_scroll(-1, "units")
            elif event.num == 5:
                self.yview_scroll(1, "units")

    def destroy(self):
        if platform.system() == 'Linux':
            self.eventCanvas.unbind_all("<Button-4>")
            self.eventCanvas.unbind_all("<Button-5>")

            self.eventCanvas.unbind_all("<Shift-Button-4>")
            self.eventCanvas.unbind_all("<Shift-Button-5>")
        else:
            self.eventCanvas.unbind_all("<MouseWheel>")
        super().destroy()


class TlViewer(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, model, view, controller, plugin, **kwargs):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._plugin = plugin
        self._kwargs = kwargs
        super().__init__()

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if platform.system() != 'Windows':
            self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        self._ui.views.append(self)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = TlFrame(self)

        if self._mdl.novel is not None:
            self.mainWindow.eventCanvas.events = self._mdl.novel.sections
            self.mainWindow.eventCanvas.startTimestamp = get_timestamp(
                datetime.fromisoformat(self._mdl.novel.referenceDate))
        self.isOpen = True
        self.mainWindow.pack(fill='both', expand=True, padx=2, pady=2)

        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(side='right', padx=5, pady=5)

    def on_quit(self, event=None):
        self.isOpen = False
        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self.mainWindow.destroy()
        self.destroy()

        self._ui.views.remove(self)


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_tlview', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Timeline view')
PLUGIN = f'{APPLICATION} plugin v0.2.1'


class Plugin(PluginBase):
    VERSION = '0.2.1'
    API_VERSION = '4.4'
    DESCRIPTION = 'A timeline view'
    URL = 'https://github.com/peter88213/nv_tlview'
    _HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_tlview/'

    def install(self, model, view, controller, prefs=None):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._start_ui)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

        self._ui.helpMenu.add_command(label=_('Timeline view Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        self._tlViewer = None
        self.kwargs = {
            'window_geometry': '2000x400',
        }

    def _start_ui(self):
        if not self._mdl.prjFile:
            return

        if self._tlViewer:
            if self._tlViewer.isOpen:
                self._tlViewer.lift()
                self._tlViewer.focus()
                return

        self._tlViewer = TlViewer(self._mdl, self._ui, self._ctrl, self, **self.kwargs)
        self._tlViewer.title(f'{self._mdl.novel.title} - {PLUGIN}')

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

