"""A timeline view plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_tlview
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path

import os
import sys
import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass
import gettext
import locale
import webbrowser

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_tlview', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

MAJOR_HEIGHT = 15
MAJOR_WIDTH_MIN = 120
MAJOR_WIDTH_MAX = 360

HOUR = 3600
DAY = HOUR * 24
YEAR = DAY * 365

HELP_URL = 'https://github.com/peter88213/nv_tlview/tree/main/docs/nv_tlview'


def open_help(event=None):
    webbrowser.open(HELP_URL)

from tkinter import ttk


class TlButton:

    def __init__(self, view, text, icon, command):
        self._ui = view
        self._toolbarButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=text,
            image=icon,
            command=command
            )
        self._toolbarButton.pack(side='left')
        self._toolbarButton.image = icon

    def disable(self):
        self._toolbarButton.config(state='disabled')

    def enable(self):
        self._toolbarButton.config(state='normal')
from datetime import datetime
from pathlib import Path

from calendar import isleap
from datetime import date
from datetime import datetime
from datetime import timedelta


def difference_in_years(startDate, endDate):
    diffyears = endDate.year - startDate.year
    difference = endDate - startDate.replace(endDate.year)
    days_in_year = isleap(endDate.year) and 366 or 365
    years = diffyears + (difference.days + difference.seconds / 86400.0) / days_in_year
    return int(years)


def get_age(nowIso, birthDateIso, deathDateIso):
    now = datetime.fromisoformat(nowIso)
    if deathDateIso:
        deathDate = datetime.fromisoformat(deathDateIso)
        if now > deathDate:
            years = difference_in_years(deathDate, now)
            return -1 * years

    birthDate = datetime.fromisoformat(birthDateIso)
    years = difference_in_years(birthDate, now)
    return years


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)

from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

from datetime import datetime
from datetime import timedelta


def from_timestamp(ts):
    return datetime.min + timedelta(seconds=ts)


def get_timestamp(dt):
    return int((dt - datetime.min).total_seconds() + 0.5)


def get_seconds(days, hours, minutes):
    seconds = 0
    if days:
        seconds = int(days) * 24 * 3600
    if hours:
        seconds += int(hours) * 3600
    if minutes:
        seconds += int(minutes) * 60
    return seconds

from datetime import datetime
import platform
from tkinter import ttk

from tkinter import ttk
from calendar import day_abbr


class ScaleCanvas(tk.Canvas):

    def __init__(self, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self['background'] = 'dimgray'
        self._majorScaleColor = 'white'

    def draw(self, startTimestamp, scale):
        self.delete("all")


        resolution = HOUR
        self.majorWidth = resolution / scale
        units = 0
        while self.majorWidth < MAJOR_WIDTH_MIN:
            resolution *= 2
            if units == 0 and resolution > DAY:
                resolution = DAY
                units = 1
            elif units == 1 and resolution > YEAR:
                resolution = YEAR
                units = 2
            self.majorWidth = resolution / scale

        tsOffset = resolution - startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / scale
        timestamp = startTimestamp + tsOffset

        xMax = self.winfo_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            weekDay = day_abbr[dt.weekday()]
            if units == 0:
                dtStr = f"{weekDay} {dt.strftime('%x')} {dt.hour:02}:{dt.minute:02}"
            elif units == 1:
                dtStr = f"{weekDay} {dt.strftime('%x')}"
            elif units == 2:
                dtStr = f"{dt.strftime('%x')}"

            self.create_line((xPos, 0), (xPos, MAJOR_HEIGHT), width=1, fill=self._majorScaleColor)
            self.create_text((xPos + 5, 2), text=dtStr, fill='white', anchor='nw')
            xPos += self.majorWidth
            timestamp += resolution

    def _get_window_width(self):
        self.update()
        return self.winfo_width()
from calendar import day_abbr


class SectionCanvas(tk.Canvas):
    EVENT_DIST_Y = 35
    LABEL_DIST_X = 10
    MARK_HALF = 5

    def __init__(self, controller, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._ctrl = controller
        self['background'] = 'black'
        self.eventMarkColor = 'red'
        self.eventTitleColor = 'white'
        self.eventDateColor = 'darkgray'
        self.indicatorColor = 'lightblue'
        self.srtSections = []
        self.yMax = 0

    def draw(self, startTimestamp, scale, srtSections, minDist):
        self.delete("all")
        self.yMax = (len(srtSections) + 2) * self.EVENT_DIST_Y
        self.configure(scrollregion=(0, 0, 0, self.yMax))
        yStart = self.EVENT_DIST_Y
        xEnd = 0
        yPos = yStart
        labelEnd = 0
        for section in srtSections:
            timestamp, duration, title, eventId = section
            xStart = (timestamp - startTimestamp) / scale
            dt = from_timestamp(timestamp)
            weekDay = day_abbr[dt.weekday()]
            timeStr = f"{weekDay} {dt.strftime('%x')} {dt.hour:02}:{dt.minute:02}"

            if xStart > labelEnd + minDist:
                yPos = yStart
                labelEnd = 0

            xEnd = (timestamp - startTimestamp + duration) / scale
            sectionMark = self.create_polygon(
                (xStart, yPos - self.MARK_HALF),
                (xStart - self.MARK_HALF, yPos),
                (xStart, yPos + self.MARK_HALF),
                (xEnd, yPos + self.MARK_HALF),
                (xEnd + self.MARK_HALF, yPos),
                (xEnd, yPos - self.MARK_HALF),
                fill=self.eventMarkColor,
                tags=eventId
                )
            self.tag_bind(sectionMark, '<Double-Button-1>', self._on_double_click)

            xLabel = xEnd + self.LABEL_DIST_X
            titleLabel = self.create_text((xLabel, yPos), text=title, fill=self.eventTitleColor, anchor='w')
            titleBounds = self.bbox(titleLabel)
            if titleBounds is not None:
                timeLabel = self.create_text(xLabel, titleBounds[3], text=timeStr, fill=self.eventDateColor, anchor='nw')
                timeBounds = self.bbox(timeLabel)
                labelEnd = max(titleBounds[2], timeBounds[2])
            yPos += self.EVENT_DIST_Y

    def _get_section_id(self, event):
        return event.widget.itemcget('current', 'tag').split(' ')[0]

    def _on_double_click(self, event):
        scId = self._get_section_id(event)
        self._ctrl.go_to_section(scId)

    def draw_indicator(self, xPos):
        self.create_line(
            (xPos, 0),
            (xPos, self.yMax),
            width=1,
            dash=(2, 2),
            fill=self.indicatorColor,
            )


class TlFrame(ttk.Frame):
    SCALE_HEIGHT = MAJOR_HEIGHT + 5

    def __init__(self, parent, controller, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)

        self.scaleCanvas = ScaleCanvas(
            self,
            height=self.SCALE_HEIGHT,
            borderwidth=0,
            highlightthickness=0
            )
        self.scaleCanvas.pack(
            anchor='n',
            fill='x',
            )

        self.sectionCanvas = SectionCanvas(
            controller,
            self,
            borderwidth=0,
            highlightthickness=0
            )
        self.sectionCanvas.configure(yscrollcommand=scrollY.set)
        self.sectionCanvas.pack(
            anchor='n',
            fill='both',
            expand=True
            )
        self.sectionCanvas.xview_moveto(0)
        self.sectionCanvas.yview_moveto(0)

        if platform.system() == 'Linux':
            self.sectionCanvas.bind("<Button-4>", self.on_mouse_wheel)
            self.sectionCanvas.bind("<Button-5>", self.on_mouse_wheel)
        else:
            self.sectionCanvas.bind("<MouseWheel>", self.on_mouse_wheel)

    def yview(self, *args):
        self.sectionCanvas.yview(*args)

    def xview(self, *args):
        self.sectionCanvas.xview(*args)

    def yview_scroll(self, *args):
        self.sectionCanvas.yview_scroll(*args)

    def on_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.yview_scroll(-1, "units")
            elif event.num == 5:
                self.yview_scroll(1, "units")

    def destroy(self):
        if platform.system() == 'Linux':
            self.sectionCanvas.unbind_all("<Button-4>")
            self.sectionCanvas.unbind_all("<Button-5>")
            self.sectionCanvas.unbind_all("<Control-Button-4>")
            self.sectionCanvas.unbind_all("<Control-Button-5>")
            self.sectionCanvas.unbind_all("<Shift-Button-4>")
            self.sectionCanvas.unbind_all("<Shift-Button-5>")
            self.sectionCanvas.unbind_all("<Control-Shift-Button-4>")
            self.sectionCanvas.unbind_all("<Control-Shift-Button-5>")
        else:
            self.sectionCanvas.unbind_all("<MouseWheel>")
            self.sectionCanvas.unbind_all("<Control-MouseWheel>")
            self.sectionCanvas.unbind_all("<Shift-MouseWheel>")
            self.sectionCanvas.unbind_all("<Control-Shift-MouseWheel>")
        super().destroy()



class TlView(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    MIN_TIMESTAMP = get_timestamp(datetime.min)
    MAX_TIMESTAMP = get_timestamp(datetime.max)

    DISTANCE_MIN = -50
    DISTANCE_MAX = 200
    PAD_X = 100

    SCALE_MIN = 10
    SCALE_MAX = YEAR * 5

    def __init__(self, model, controller, kwargs):
        self._mdl = model
        self._ctrl = controller
        self._kwargs = kwargs
        super().__init__()

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.update()

        self._skipUpdate = False
        self.isOpen = True

        self._scale = self.SCALE_MIN
        self._startTimestamp = None
        self._minDist = 0

        self.tlFrame = TlFrame(self, self._ctrl)
        self.tlFrame.pack(fill='both', expand=True, padx=2, pady=2)
        self._bind_tl_scroll()

        self.bind('<Configure>', self.draw_timeline)
        self.bind('<F1>', open_help)
        self.protocol("WM_DELETE_WINDOW", self._ctrl.on_quit)
        if platform.system() != 'Windows':
            self.bind(self._KEY_QUIT_PROGRAM[0], self._ctrl.on_quit)

        self._substituteMissingTime = self._kwargs['substitute_missing_time']
        self._convertDays = self._kwargs['convert_days']
        self._substituteMissingDate = self._kwargs['substitute_missing_date']

        self._build_menu()
        self._build_toolbar()
        self.fit_window()

    @property
    def startTimestamp(self):
        return self._startTimestamp

    @startTimestamp.setter
    def startTimestamp(self, newVal):
        if newVal < self.MIN_TIMESTAMP:
            self._startTimestamp = self.MIN_TIMESTAMP
        elif newVal > self.MAX_TIMESTAMP:
            self._startTimestamp = self.MAX_TIMESTAMP
        else:
            self._startTimestamp = newVal
        self.draw_timeline()

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, newVal):
        if newVal < self.SCALE_MIN:
            self._scale = self.SCALE_MIN
        elif newVal > self.SCALE_MAX:
            self._scale = self.SCALE_MAX
        else:
            self._scale = newVal
        self.draw_timeline()

    @property
    def minDist(self):
        return self._minDist

    @minDist.setter
    def minDist(self, newVal):
        if newVal < self.DISTANCE_MIN:
            self._minDist = self.DISTANCE_MIN
        elif newVal > self.DISTANCE_MAX:
            self._minDist = self.DISTANCE_MAX
        else:
            self._minDist = newVal
        self.draw_timeline()

    def draw_timeline(self, event=None):
        self.sort_sections()
        if self.startTimestamp is None:
            self.startTimestamp = self.firstTimestamp
        self.tlFrame.scaleCanvas.draw(
            self.startTimestamp,
            self.scale
            )
        self.tlFrame.sectionCanvas.draw(
            self.startTimestamp,
            self.scale,
            self.srtSections,
            self.minDist,
            )

    def fit_window(self):
        self.sort_sections()
        width = self.tlFrame.scaleCanvas._get_window_width() - 2 * self.PAD_X
        self.scale = (self.lastTimestamp - self.firstTimestamp) / width
        self._set_first_event()

    def go_to_first(self, event=None):
        xPos = self._set_first_event()
        self.tlFrame.sectionCanvas.draw_indicator(xPos)

    def go_to_last(self, event=None):
        xPos = self._set_last_event()
        self.tlFrame.sectionCanvas.draw_indicator(xPos)

    def go_to_selected(self, event=None):
        xPos = self.tlFrame.scaleCanvas._get_window_width() / 2
        selectedTimestamp = self._ctrl.get_selected_section_timestamp()
        if selectedTimestamp is None:
            return

        self.startTimestamp = selectedTimestamp - xPos * self.scale
        self.tlFrame.sectionCanvas.draw_indicator(xPos)

    def on_control_mouse_wheel(self, event):
        deltaScale = 1.5
        if event.num == 5 or event.delta == -120:
            self.scale *= deltaScale
        if event.num == 4 or event.delta == 120:
            self.scale /= deltaScale
        return 'break'

    def on_control_shift_mouse_wheel(self, event):
        deltaDist = 10
        if event.num == 5 or event.delta == -120:
            self.minDist += deltaDist
        if event.num == 4 or event.delta == 120:
            self.minDist -= deltaDist
        return 'break'

    def on_quit(self, event=None):
        self._kwargs['window_geometry'] = self.winfo_geometry()
        self.tlFrame.destroy()
        self.destroy()

    def refresh(self):
        if not self._skipUpdate:
            self.draw_timeline()

    def on_shift_mouse_wheel(self, event):
        deltaOffset = self.scale / self.SCALE_MIN * self.tlFrame.scaleCanvas.majorWidth
        if event.num == 5 or event.delta == -120:
            self.startTimestamp += deltaOffset
        if event.num == 4 or event.delta == 120:
            self.startTimestamp -= deltaOffset
        return 'break'

    def reset_casc(self, event=None):
        self.minDist = 0

    def set_casc_relaxed(self, event=None):
        self.minDist = self.DISTANCE_MAX

    def set_casc_tight(self, event=None):
        self.minDist = self.DISTANCE_MIN

    def set_day_scale(self, event=None):
        self.scale = (DAY * 2) / (MAJOR_WIDTH_MAX - MAJOR_WIDTH_MIN)

    def set_hour_scale(self, event=None):
        self.scale = (HOUR * 2) / (MAJOR_WIDTH_MAX - MAJOR_WIDTH_MIN)

    def set_year_scale(self, event=None):
        self.scale = (YEAR * 2) / (MAJOR_WIDTH_MAX - MAJOR_WIDTH_MIN)

    def sort_sections(self):
        srtSections = []
        for scId in self._mdl.novel.sections:
            section = self._mdl.novel.sections[scId]
            if section.scType != 0:
                continue

            try:
                refIso = self._mdl.novel.referenceDate
                if section.time is None:
                    if not self._substituteMissingTime:
                        continue

                    scTime = '00:00'
                else:
                    scTime = section.time

                if section.date is not None:
                    scDate = section.date
                elif section.day is not None:
                    if not self._convertDays:
                        continue

                    if refIso is None:
                        continue

                    scDate = get_specific_date(section.day, refIso)
                elif refIso is not None:
                    if not self._substituteMissingDate:
                        continue

                    scDate = refIso
                else:
                    continue

                srtSections.append(
                        (
                        get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}')),
                        get_seconds(section.lastsDays, section.lastsHours, section.lastsMinutes),
                        section.title,
                        scId
                        )
                    )
            except:
                pass
        self.srtSections = sorted(srtSections)
        if len(self.srtSections) > 1:
            self.firstTimestamp = self.srtSections[0][0]
            self.lastTimestamp = self.srtSections[-1][0] + self.srtSections[-1][1]
        else:
            self.firstTimestamp = self.MIN_TIMESTAMP
            self.lastTimestamp = self.MAX_TIMESTAMP

    def _bind_tl_scroll(self):
        if platform.system() == 'Linux':
            self.tlFrame.sectionCanvas.bind("<Control-Button-4>", self.on_control_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Button-5>", self.on_control_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Shift-Button-5>", self.on_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Shift-Button-4>", self.on_control_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Shift-Button-5>", self.on_control_shift_mouse_wheel)
        else:
            self.tlFrame.sectionCanvas.bind("<Control-MouseWheel>", self.on_control_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Shift-MouseWheel>", self.on_control_shift_mouse_wheel)

    def _build_menu(self):
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.goMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Go to'), menu=self.goMenu)
        self.goMenu.add_command(label=_('First event'), command=self.go_to_first)
        self.goMenu.add_command(label=_('Last event'), command=self.go_to_last)
        self.goMenu.add_command(label=_('Selected section'), command=self.go_to_selected)

        self._substTime = tk.BooleanVar(value=self._substituteMissingTime)
        self._convDays = tk.BooleanVar(value=self._convertDays)
        self._substDate = tk.BooleanVar(value=self._substituteMissingDate)

        self.scaleMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Scale'), menu=self.scaleMenu)
        self.scaleMenu.add_command(label=_('Hours'), command=self.set_hour_scale)
        self.scaleMenu.add_command(label=_('Days'), command=self.set_day_scale)
        self.scaleMenu.add_command(label=_('Years'), command=self.set_year_scale)
        self.scaleMenu.add_command(label=_('Fit to window'), command=self.fit_window)

        self.substMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Substitutions'), menu=self.substMenu)
        self.substMenu.add_checkbutton(
            label=_('Use 00:00 for missing times'),
            variable=self._substTime,
            command=self._set_substitute_missing_time
            )
        self.substMenu.add_checkbutton(
            label=_('Convert days to dates'),
            variable=self._convDays,
            command=self._set_convert_days
            )
        self.substMenu.add_checkbutton(
            label=_('Use reference for missing dates'),
            variable=self._substDate,
            command=self._set_substitute_missing_date
            )

        self.cascadeMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Cascading'), menu=self.cascadeMenu)
        self.cascadeMenu.add_command(label=_('Tight'), command=self.set_casc_tight)
        self.cascadeMenu.add_command(label=_('Relaxed'), command=self.set_casc_relaxed)
        self.cascadeMenu.add_command(label=_('Standard'), command=self.reset_casc)

        self.helpMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator='F1', command=open_help)

    def _build_toolbar(self):
        self.toolbar = ttk.Frame(self)
        self.toolbar.pack(fill='x', padx=5, pady=2)

        toolbarIcons = self._ctrl.get_toolbar_icons()
        goToFirst = ttk.Button(
            self.toolbar,
            text=_('First event'),
            image=toolbarIcons['goToFirst'],
            command=self.go_to_first
            )
        goToFirst.pack(side='left')
        goToFirst.image = toolbarIcons['goToFirst']

        goToLast = ttk.Button(
            self.toolbar,
            text=_('Last event'),
            image=toolbarIcons['goToLast'],
            command=self.go_to_last
            )
        goToLast.pack(side='left')
        goToLast.image = toolbarIcons['goToLast']

        goToSelected = ttk.Button(
            self.toolbar,
            text=_('Selected section'),
            image=toolbarIcons['goToSelected'],
            command=self.go_to_selected
            )
        goToSelected.pack(side='left')
        goToSelected.image = toolbarIcons['goToSelected']

        fitToWindow = ttk.Button(
            self.toolbar,
            text=_('Fit to window'),
            image=toolbarIcons['fitToWindow'],
            command=self.fit_window
            )
        fitToWindow.pack(side='left')
        fitToWindow.image = toolbarIcons['fitToWindow']

        ttk.Button(
            self.toolbar,
            text=_('Close'),
            command=self._ctrl.on_quit
            ).pack(side='right')

    def _set_first_event(self):
        xPos = self.PAD_X
        self.startTimestamp = self.firstTimestamp - xPos * self.scale
        if self.startTimestamp < self.MIN_TIMESTAMP:
            self.startTimestamp = self.MIN_TIMESTAMP
        return xPos

    def _set_last_event(self):
        xPos = self.tlFrame.scaleCanvas._get_window_width() - self.PAD_X
        self.startTimestamp = self.lastTimestamp - xPos * self.scale
        return xPos

    def _set_substitute_missing_time(self):
        self._substituteMissingTime = self._substTime.get()
        self._kwargs['substitute_missing_time'] = self._substituteMissingTime
        self.draw_timeline()

    def _set_convert_days(self):
        self._convertDays = self._convDays.get()
        self._kwargs['convert_days'] = self._convertDays
        self.draw_timeline()

    def _set_substitute_missing_date(self):
        self._substituteMissingDate = self._substDate.get()
        self._kwargs['substitute_missing_date'] = self._substituteMissingDate
        self.draw_timeline()



class TlController:

    def __init__(self, model, view, controller, kwargs):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        prefs = self._ctrl.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None

        self._toolbarIcons = {}
        icons = [
            'goToFirst',
            'goToLast',
            'goToSelected',
            'fitToWindow'
            ]
        for icon in icons:
            try:
                self._toolbarIcons[icon] = tk.PhotoImage(file=f'{iconPath}/{icon}.png')
            except:
                self._toolbarIcons[icon] = None

        self.view = TlView(self._mdl, self, kwargs)
        self._ui.register_view(self.view)
        self.isOpen = True

        self.firstTimestamp = None
        self.lastTimestamp = None

        self._substituteMissingTime = kwargs['substitute_missing_time']
        self._convertDays = kwargs['convert_days']
        self._substituteMissingDate = kwargs['substitute_missing_date']

    def get_toolbar_icons(self):
        return self._toolbarIcons

    def on_quit(self):
        if not self.isOpen:
            return

        self.view.on_quit()
        self._ui.unregister_view(self.view)
        del(self.view)
        self.isOpen = False

    def open_viewer(self):
        if self.view.state() == 'iconic':
            self.view.state('normal')
        self.view.lift()
        self.view.focus()

    def go_to_section(self, scId):
        self._ui.tv.go_to_node(scId)

    def get_selected_section_timestamp(self):
        scId = self._ui.tv.tree.selection()[0]
        if not scId.startswith(SECTION_PREFIX):
            return

        section = self._mdl.novel.sections[scId]
        if section.scType != 0:
            return

        try:
            refIso = self._mdl.novel.referenceDate
            if section.time is None:
                if not self._substituteMissingTime:
                    return

                scTime = '00:00'
            else:
                scTime = section.time

            if section.date is not None:
                scDate = section.date
            elif section.day is not None:
                if not self._convertDays:
                    return

                if refIso is None:
                    return

                scDate = get_specific_date(section.day, refIso)
            elif refIso is not None:
                if not self._substituteMissingDate:
                    return

                scDate = refIso
            else:
                return

            return get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}'))

        except:
            return


SETTINGS = dict(
    window_geometry='600x800',
)
OPTIONS = dict(
    substitute_missing_time=False,
    convert_days=False,
    substitute_missing_date=False,
)

APPLICATION = _('Timeline view')
PLUGIN = f'{APPLICATION} plugin v0.10.2'


class Plugin(PluginBase):
    VERSION = '0.10.2'
    API_VERSION = '4.5'
    DESCRIPTION = 'A timeline view'
    URL = 'https://github.com/peter88213/nv_tlview'

    def install(self, model, view, controller, prefs=None):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ctrl = controller
        self._ui = view
        self._tlUi = None
        self._tlCtrl = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.novx/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/tlview.ini'
        self.configuration = self._mdl.nvService.make_configuration(
            settings=SETTINGS,
            options=OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._open_viewer)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

        self._ui.helpMenu.add_command(label=_('Timeline view Online help'), command=open_help)


        prefs = controller.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None
        try:
            tlIcon = tk.PhotoImage(file=f'{iconPath}/tlview.png')
        except:
            tlIcon = None

        tk.Frame(view.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._tlButton = TlButton(view, _('Timeline view'), tlIcon, self._open_viewer)

    def _open_viewer(self):
        if not self._mdl.prjFile:
            return

        if self._tlCtrl is not None and self._tlCtrl.isOpen:
            self._tlCtrl.open_viewer()
            return

        self._tlCtrl = TlController(self._mdl, self._ui, self._ctrl, self.kwargs)
        self._tlCtrl.view.title(f'{self._mdl.novel.title} - {PLUGIN}')
        set_icon(self._tlCtrl.view, icon='tLogo32', default=False)

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')
        self._tlButton.disable()

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')
        self._tlButton.enable()

    def on_close(self):
        """Actions to be performed when a project is closed.
        
        Overrides the superclass method.
        """
        self._tlCtrl.on_quit()

    def on_quit(self):
        """Actions to be performed when novelibre is closed.
        
        Overrides the superclass method.
        """
        if self._tlCtrl is None:
            return

        self._tlCtrl.on_quit()
        self._tlCtrl = None

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
