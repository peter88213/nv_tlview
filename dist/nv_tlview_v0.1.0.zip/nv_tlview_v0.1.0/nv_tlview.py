"""A timeline view plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_tlview
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys
import os
import tkinter as tk
import locale
import gettext
import webbrowser
from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass
from nvtlviewlib.tl_canvas import TlCanvas
from nvtlviewlib.dt_helper import get_timestamp
from datetime import datetime

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_tlview', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Timeline view')
PLUGIN = f'{APPLICATION} plugin v0.1.0'


class Plugin(PluginBase):
    VERSION = '0.1.0'
    API_VERSION = '4.4'
    DESCRIPTION = 'A timeline view'
    URL = 'https://github.com/peter88213/nv_tlview'
    _HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_tlview/'

    def install(self, model, view, controller, prefs=None):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._start_ui)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

        self._ui.helpMenu.add_command(label=_('Timeline view Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        self._tlViewer = None

    def _start_ui(self):
        if not self._mdl.prjFile:
            return

        canvas = TlCanvas(
            self._ui.root,
            background='black',
            width=2000,
            height=200,
            )
        canvas.pack()
        canvas.events = self._mdl.novel.sections
        canvas.startTimestamp = get_timestamp(
            datetime.fromisoformat(self._mdl.novel.referenceDate))
        return

        if self._tlViewer:
            if self._tlViewer.isOpen:
                self._tlViewer.lift()
                self._tlViewer.focus()
                return

        self._tlViewer = TlCanvas(self._mdl, self._ui, self._ctrl, self, **self.kwargs)
        self._tlViewer.title(f'{self._mdl.novel.title} - {PLUGIN}')

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

