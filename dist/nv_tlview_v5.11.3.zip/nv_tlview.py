"""A timeline view plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_tlview
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_tlview',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE]
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
import webbrowser



class TlviewHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_tlview/'

    @classmethod
    def open_help_page(cls):
        webbrowser.open(cls.HELP_URL)

from pathlib import Path



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_REPORT_SUFFIX = '_projectnotes_report'
PROJECTNOTES_SUFFIX = '_projectnotes_tmp'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


from datetime import datetime


prefs = {}

HOUR = 3600
DAY = HOUR * 24
YEAR = DAY * 365
MONTH = DAY * 30

from datetime import date
from datetime import datetime
from datetime import timedelta



def from_timestamp(ts):
    return datetime.min + timedelta(seconds=ts)


def get_duration(seconds):
    minutes = seconds // 60
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    return days, hours, minutes


def get_duration_str(days, hours, minutes):
    durationStr = ''
    if days:
        durationStr = f' {days} {_("d")}'
    if hours:
        durationStr = f' {durationStr} {hours} {_("h")}'
    if minutes:
        durationStr = f' {durationStr} {minutes} {_("m")}'
    return durationStr


def get_seconds(days, hours, minutes):
    seconds = 0
    if days:
        seconds = int(days) * 24 * 3600
    if hours:
        seconds += int(hours) * 3600
    if minutes:
        seconds += int(minutes) * 60
    return seconds


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_timestamp(dt):
    return int((dt - datetime.min).total_seconds() + 0.5)


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)

from calendar import day_abbr
from datetime import datetime
from tkinter import ttk

import platform



class GenericKeys:

    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')


class GenericMouse:

    ADJUST_CASCADING = '<Control-Shift-MouseWheel>'
    LEFT_CLICK = '<Button-1>'
    MOVE_TIME_SCALE = '<Shift-MouseWheel>'
    RIGHT_CLICK = '<Button-3>'
    RIGHT_MOTION = '<B3-Motion>'
    RIGHT_RELEASE = '<ButtonRelease-3>'
    STRETCH_TIME_SCALE = '<Control-MouseWheel>'


class LinuxMouse(GenericMouse):

    BACK_SCROLL = '<Button-4>'
    FORWARD_SCROLL = '<Button-5>'
    ADJUST_CASCADING_BCK = '<Control-Shift-Button-4>'
    ADJUST_CASCADING_FWD = '<Control-Shift-Button-5>'
    MOVE_TIME_SCALE_BCK = '<Shift-Button-4>'
    MOVE_TIME_SCALE_FWD = '<Shift-Button-5>'
    STRETCH_TIME_SCALE_BCK = '<Control-Button-4>'
    STRETCH_TIME_SCALE_FWD = '<Control-Button-5>'



class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')



class MacMouse(GenericMouse):

    ADJUST_CASCADING = '<Command-Shift-MouseWheel>'
    RIGHT_CLICK = '<Button-2>'
    RIGHT_MOTION = '<B2-Motion>'
    RIGHT_RELEASE = '<ButtonRelease-2>'
    STRETCH_TIME_SCALE = '<Command-MouseWheel>'



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')



class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = LinuxMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from _datetime import date
from calendar import day_abbr
from calendar import month_abbr



class TlvScaleCanvas(tk.Canvas):

    CANVAS_HEIGHT = 30
    MAJOR_HEIGHT = 15
    SCALE_SPACING_MIN = 120
    MINOR_SPACING_MIN = 40

    def __init__(self, tlvController, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._tlvCtrl = tlvController
        self.majorSpacing = None
        self.minorSpacing = None

    def draw(
        self,
        startTimestamp,
        scale,
        specificDate,
        refIso,
        background,
    ):
        self['background'] = background
        self.delete("all")
        if not specificDate:
            if refIso is None:
                refIso = '0001-01-01'
                showWeekDay = False
            else:
                showWeekDay = True


        resolution, self.majorSpacing, units = self._calculate_resolution(
            scale,
            HOUR,
            self.SCALE_SPACING_MIN
            )
        xPos, timestamp = self._calculate_first_scale_line(
            resolution,
            startTimestamp,
            scale
            )

        xMax = self.get_window_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                weekDay = day_abbr[dt.weekday()]
                month = month_abbr[dt.month]
                if units == 0:
                    dtStr = f"{weekDay} {self._tlvCtrl.datestr(dt)}"
                elif units == 1:
                    dtStr = f"{weekDay} {self._tlvCtrl.datestr(dt)}"
                elif units == 2:
                    dtStr = f"{month} {dt.year}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                if showWeekDay:
                    weekDay = f'{day_abbr[dt.weekday()]} '
                else:
                    weekDay = ''
                if units == 0:
                    dtStr = f"{weekDay} {_('Day')} {day}"
                elif units == 1:
                    dtStr = f"{weekDay} {_('Day')} {day}"
                elif units == 2:
                    dtStr = f"{_('Day')} {day}"
                elif units == 3:
                    dtStr = f"{_('Day')} {day}"

            self.create_line(
                (xPos, 0),
                (xPos, self.MAJOR_HEIGHT),
                width=1,
                fill=prefs['color_major_scale'],
                )
            self.create_text(
                (xPos + 5, 2),
                text=dtStr,
                fill=prefs['color_major_scale'],
                anchor='nw',
                )
            xPos += self.majorSpacing
            timestamp += resolution


        resolution /= 4
        self.minorSpacing = resolution / scale
        while self.minorSpacing < self.MINOR_SPACING_MIN:
            resolution *= 2
            if units == 0 and resolution >= DAY:
                resolution = DAY
            elif units == 1 and resolution >= YEAR:
                resolution = YEAR
            self.minorSpacing = resolution / scale
        xPos, timestamp = self._calculate_first_scale_line(
            resolution,
            startTimestamp,
            scale
            )

        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                weekDay = day_abbr[dt.weekday()]
                month = month_abbr[dt.month]
                if units == 0:
                    dtStr = f"{dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = f"{weekDay} {dt.day}"
                elif units == 2:
                    dtStr = f"{month}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                weekDay = day_abbr[dt.weekday()]
                if units == 0:
                    dtStr = f"{dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = day
                elif units == 2:
                    dtStr = day
                elif units == 3:
                    dtStr = day

            self.create_line(
                (xPos, self.MAJOR_HEIGHT),
                (xPos, self.CANVAS_HEIGHT),
                width=1,
                fill=prefs['color_minor_scale'],
                )
            self.create_text(
                (xPos + 5, self.MAJOR_HEIGHT + 1),
                text=dtStr,
                fill=prefs['color_minor_scale'],
                anchor='nw',
                )
            xPos += self.minorSpacing
            timestamp += resolution

    def get_window_width(self):
        self.update()
        return self.winfo_width()

    def _calculate_first_scale_line(self, resolution, startTimestamp, scale):
        tsOffset = resolution - startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / scale
        timestamp = startTimestamp + tsOffset
        return xPos, timestamp

    def _calculate_resolution(self, scale, resolution, spacingMin):
        spacing = resolution / scale
        units = 0
        while spacing < spacingMin:
            resolution *= 2
            if units == 0 and resolution >= DAY:
                resolution = DAY
                units = 1
            elif units == 1 and resolution >= MONTH:
                resolution = MONTH
                units = 2
            elif units == 2 and resolution >= YEAR:
                resolution = YEAR
                units = 3
            spacing = resolution / scale
        return resolution, spacing, units

from tkinter import ttk

from _datetime import date
from calendar import day_abbr
from calendar import month_abbr



class TlvOverviewCanvas(TlvScaleCanvas):

    CANVAS_HEIGHT = 30
    OV_DATE_POS = 12
    OV_SC_Y_POS = 7
    OV_SC_X_MIN = 2
    OV_SC_THICKNESS = 4

    OV_SPACING_RATIO = 2
    OV_SCALE_RATIO = 9

    def __init__(self, tlvController, master=None, **kw):
        super().__init__(tlvController, master, **kw)

    def draw(
        self,
        startTimestamp,
        scale,
        specificDate,
        refIso,
        srtSections,
        background,
    ):
        self['background'] = background
        self.delete("all")
        if not specificDate:
            if refIso is None:
                refIso = '0001-01-01'

        scale *= self.OV_SCALE_RATIO
        xMax = self.get_window_width()
        windowMarkWidth = xMax / self.OV_SCALE_RATIO
        windowMarkStart = windowMarkWidth * (self.OV_SCALE_RATIO // 2)
        self.create_rectangle(
            windowMarkStart,
            0,
            windowMarkStart + windowMarkWidth,
            self.CANVAS_HEIGHT,
            fill=prefs['color_window_mark'],
            width=0,
        )

        startTimestamp -= (windowMarkStart * scale)
        resolution, self.majorSpacing, units = self._calculate_resolution(
            scale,
            HOUR,
            self.SCALE_SPACING_MIN * self.OV_SPACING_RATIO,
        )
        xPos, timestamp = self._calculate_first_scale_line(
            resolution,
            startTimestamp,
            scale,
        )

        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                month = month_abbr[dt.month]
                weekDay = day_abbr[dt.weekday()]
                if units == 0:
                    dtStr = f"{weekDay} {dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = self._tlvCtrl.datestr(dt)
                elif units == 2:
                    dtStr = f"{month} {dt.year}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                if units == 0:
                    dtStr = f"{_('Day')} {day} {dt.hour:02}:{dt.minute:02}"
                else:
                    dtStr = f"{_('Day')} {day}"

            self.create_text(
                (xPos + 5, self.OV_DATE_POS),
                text=dtStr,
                fill=prefs['color_major_scale'],
                anchor='nw',
            )
            xPos += self.majorSpacing
            timestamp += resolution

        for section in srtSections:
            timestamp, durationSeconds, __, __, __, sectionColor = section
            xStart = (timestamp - startTimestamp) / scale
            xEnd = (timestamp - startTimestamp + durationSeconds) / scale
            if xEnd - xStart < self.OV_SC_X_MIN:
                xEnd += self.OV_SC_X_MIN
            self.create_line(
                xStart,
                self.OV_SC_Y_POS,
                xEnd,
                self.OV_SC_Y_POS,
                width=self.OV_SC_THICKNESS,
                fill=sectionColor,
            )




class TlvSectionCanvas(tk.Canvas):

    SC_EVENT_DIST_Y = 35
    SC_LABEL_DIST_X = 10
    SC_MARK_HALF = 5

    isLocked = False

    def __init__(self, tlvController, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._tlvCtrl = tlvController
        self.yMax = 0

        self._xPos = None
        self._xStart = None
        self._active_object = None
        self._indicator = None
        self._indicatorText = None

        self.bind_all('<Escape>', self._on_escape)

    def delete_indicator(self):
        self.delete(self._indicator)
        self.delete(self._indicatorText)

    def draw(
        self,
        startTimestamp,
        scale, srtSections,
        minDist,
        background,
    ):
        self['background'] = background
        self.delete("all")
        self.yMax = (len(srtSections) + 2) * self.SC_EVENT_DIST_Y
        yStart = self.SC_EVENT_DIST_Y
        xEnd = 0
        yPos = yStart
        labelEnd = 0
        for section in srtSections:
            (
                timestamp,
                durationSeconds,
                title,
                timeStr,
                sectionId,
                sectionColor,
            ) = section
            xStart = (timestamp - startTimestamp) / scale

            if xStart > labelEnd + minDist:
                yPos = yStart
                labelEnd = 0

            xEnd = (timestamp - startTimestamp + durationSeconds) / scale
            sectionMark = self.create_polygon(
                (xStart, yPos - self.SC_MARK_HALF),
                (xStart - self.SC_MARK_HALF, yPos),
                (xStart, yPos + self.SC_MARK_HALF),
                (xEnd, yPos + self.SC_MARK_HALF),
                (xEnd + self.SC_MARK_HALF, yPos),
                (xEnd, yPos - self.SC_MARK_HALF),
                fill=sectionColor,
                tags=sectionId,
            )
            self.tag_bind(
                sectionMark,
                '<Double-Button-1>',
                self._on_double_click,
            )
            self.tag_bind(
                sectionMark,
                '<Shift-Button-1>',
                self._on_shift_click,
            )
            self.tag_bind(
                sectionMark,
                '<Control-Shift-Button-1>',
                self._on_ctrl_shift_click,
            )

            xLabel = xEnd + self.SC_LABEL_DIST_X
            titleLabel = self.create_text(
                (xLabel, yPos),
                text=title,
                fill=prefs['color_section_title'],
                anchor='w',
            )
            titleBounds = self.bbox(titleLabel)
            if titleBounds is not None:
                self.create_text(
                    xLabel,
                    titleBounds[3],
                    text=timeStr,
                    fill=prefs['color_section_date'],
                    anchor='nw'
                )
                __, __, x2, __ = self.bbox('all')
                labelEnd = x2
            yPos += self.SC_EVENT_DIST_Y
        totalBounds = self.bbox('all')
        if totalBounds is not None:
            self.configure(scrollregion=(0, 0, 0, totalBounds[3]))

    def draw_indicator(self, xPos, text=''):
        self.delete_indicator()
        self._indicator = self.create_line(
            (xPos, 0),
            (xPos, self.yMax),
            width=1,
            dash=(2, 2),
            fill=prefs['color_indicator'],
        )
        self._indicatorText = self.create_text(
            (xPos + 5, 5),
            text=text,
            anchor='nw',
            fill=prefs['color_indicator'],
        )

    def get_section_id(self, event):
        return event.widget.itemcget('current', 'tag').split(' ')[0]

    def _move_indicator(self, deltaX):
        self.move(self._indicator, deltaX, 0)
        self.move(self._indicatorText, deltaX, 0)

    def _on_ctrl_shift_click(self, event):
        if self.isLocked:
            return

        self._active_object = self.get_section_id(event)
        self.tag_bind(
            self._active_object,
            '<ButtonRelease-1>',
            self._on_ctrl_shift_release,
        )
        self.tag_bind(
            self._active_object,
            '<B1-Motion>',
            self._on_drag,
        )
        __, __, x2, __ = self.bbox(self._active_object)
        self._xStart = x2 - self.SC_MARK_HALF
        self._xPos = event.x
        self.draw_indicator(
            self._xStart,
            text=(
                f'{_("Shift end")}: '
                f'{self._tlvCtrl.get_section_title(self._active_object)}'
            )
        )
        self._xStart = event.x

    def _on_ctrl_shift_release(self, event):
        try:
            self.tag_unbind(self._active_object, '<ButtonRelease-1>')
            self.tag_unbind(self._active_object, '<B1-Motion>')
        except:
            return

        deltaX = event.x - self._xStart
        self._tlvCtrl.shift_section_end(self._active_object, deltaX)
        self._active_object = None
        self.delete_indicator()

    def _on_double_click(self, event):
        self.event_generate('<<double-click>>', when='tail')

    def _on_drag(self, event):
        deltaX = event.x - self._xPos
        self._xPos = event.x
        self._move_indicator(deltaX)

    def _on_escape(self, event):
        self.unbind_all('<ButtonRelease-1>')
        self.unbind_all('<B1-Motion>')
        self.delete_indicator()
        self._active_object = None

    def _on_shift_click(self, event):
        if self.isLocked:
            return

        self._active_object = self.get_section_id(event)
        self.tag_bind(
            self._active_object,
            '<ButtonRelease-1>',
            self._on_shift_release,
        )
        self.tag_bind(
            self._active_object,
            '<B1-Motion>',
            self._on_drag,
        )
        x1, __, __, __ = self.bbox(self._active_object)
        self._xStart = x1 + self.SC_MARK_HALF
        self._xPos = event.x
        self.draw_indicator(
            self._xStart,
            text=(
                f'{_("Shift start")}: '
                f'{self._tlvCtrl.get_section_title(self._active_object)}'
            )
        )
        self._xStart = event.x

    def _on_shift_release(self, event):
        try:
            self.tag_unbind(self._active_object, '<ButtonRelease-1>')
            self.tag_unbind(self._active_object, '<B1-Motion>')
        except:
            return

        deltaX = event.x - self._xStart
        self._tlvCtrl.shift_section(self._active_object, deltaX)
        self._active_object = None
        self.delete_indicator()



class TlvScrollFrame(ttk.Frame):

    def __init__(self, parent, tlvController, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)

        self._scaleCanvas = TlvScaleCanvas(
            tlvController,
            self,
            height=TlvScaleCanvas.CANVAS_HEIGHT,
            borderwidth=0,
            highlightthickness=0
            )
        self._scaleCanvas.pack(
            anchor='n',
            fill='x',
            )

        self._ovCanvas = TlvOverviewCanvas(
            tlvController,
            self,
            height=TlvOverviewCanvas.CANVAS_HEIGHT,
            borderwidth=0,
            highlightthickness=0
            )
        self._ovCanvas.pack(
            side='bottom',
            anchor='n',
            fill='x',
            )

        self._sectionCanvas = TlvSectionCanvas(
            tlvController,
            self,
            borderwidth=0,
            highlightthickness=0
            )
        self._sectionCanvas.configure(yscrollcommand=scrollY.set)
        self._sectionCanvas.pack(
            anchor='n',
            fill='both',
            expand=True
            )
        self._sectionCanvas.xview_moveto(0)
        self._sectionCanvas.yview_moveto(0)

        if PLATFORM == 'ix':
            self._sectionCanvas.bind(MOUSE.BACK_SCROLL, self.on_mouse_wheel)
            self._sectionCanvas.bind(MOUSE.FORWARD_SCROLL, self.on_mouse_wheel)
        else:
            self._sectionCanvas.bind('<MouseWheel>', self.on_mouse_wheel)

        self._yscrollincrement = self._sectionCanvas['yscrollincrement']

    def bind_section_canvas_event(self, event, command):
        self._sectionCanvas.bind(event, command)

    def destroy(self):
        if PLATFORM == 'ix':
            self._sectionCanvas.unbind_all(MOUSE.BACK_SCROLL)
            self._sectionCanvas.unbind_all(MOUSE.FORWARD_SCROLL)
            self._sectionCanvas.unbind_all(MOUSE.STRETCH_TIME_SCALE_BCK)
            self._sectionCanvas.unbind_all(MOUSE.STRETCH_TIME_SCALE_FWD)
            self._sectionCanvas.unbind_all(MOUSE.MOVE_TIME_SCALE_BCK)
            self._sectionCanvas.unbind_all(MOUSE.MOVE_TIME_SCALE_FWD)
            self._sectionCanvas.unbind_all(MOUSE.ADJUST_CASCADING_BCK)
            self._sectionCanvas.unbind_all(MOUSE.ADJUST_CASCADING_FWD)
        else:
            self._sectionCanvas.unbind_all('<MouseWheel>')
            self._sectionCanvas.unbind_all(MOUSE.STRETCH_TIME_SCALE)
            self._sectionCanvas.unbind_all(MOUSE.MOVE_TIME_SCALE)
            self._sectionCanvas.unbind_all(MOUSE.ADJUST_CASCADING)
        super().destroy()

    def draw_indicator(self, xPos, text=''):
        self._sectionCanvas.draw_indicator(xPos, text)

    def draw_timeline(
            self,
            startTimestamp,
            scale,
            srtSections,
            minDist,
            specificDate,
            referenceDate
    ):
        self._scaleCanvas.draw(
            startTimestamp,
            scale,
            specificDate,
            referenceDate,
            prefs['color_scale_background'],
        )
        self._sectionCanvas.draw(
            startTimestamp,
            scale,
            srtSections,
            minDist,
            prefs['color_section_background'],
        )
        self._ovCanvas.draw(
            startTimestamp,
            scale,
            specificDate,
            referenceDate,
            srtSections,
            prefs['color_scale_background'],
        )

    def get_canvas(self):
        return self._sectionCanvas

    def get_scale_mark_spacing(self):
        return self._scaleCanvas.majorSpacing

    def get_window_width(self):
        return self._scaleCanvas.get_window_width()

    def on_mouse_wheel(self, event):
        if PLATFORM == 'win':
            self.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif PLATFORM == 'mac':
            self.yview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.yview_scroll(-1, 'units')
            elif event.num == 5:
                self.yview_scroll(1, 'units')

    def set_drag_scrolling(self):
        self._sectionCanvas.configure(yscrollincrement=1)

    def set_normal_scrolling(self):
        self._sectionCanvas.configure(yscrollincrement=self._yscrollincrement)

    def xview(self, *args):
        self._sectionCanvas.xview(*args)

    def yview(self, *args):
        self._sectionCanvas.yview(*args)

    def yview_scroll(self, *args):
        if self._sectionCanvas.yview() == (0.0, 1.0):
            return

        self._sectionCanvas.yview_scroll(*args)



class TlvMainFrame(ttk.Frame):

    MIN_TIMESTAMP = get_timestamp(datetime.min)
    MAX_TIMESTAMP = get_timestamp(datetime.max)

    DISTANCE_MIN = -100
    DISTANCE_MAX = 200
    PAD_X = 100
    SCALE_SPACING_MAX = 480

    SCALE_MIN = 10
    SCALE_MAX = YEAR * 5

    def __init__(self, model, master, tlvController):
        ttk.Frame.__init__(self, master)

        self._dataModel = model
        self.master = master

        self._tlvCtrl = tlvController
        self.pack(fill='both', expand=True)

        self._statusText = ''
        self.isOpen = True

        self._scale = self.SCALE_MIN
        self._startTimestamp = None
        self._minDist = 0
        self._specificDate = None
        self.firstTimestamp = None
        self.lastTimestamp = None
        self.srtSections = None

        self._xPos = None
        self._yPos = None

        self.tlFrame = TlvScrollFrame(self, self._tlvCtrl)
        self.tlFrame.pack(side='top', fill='both', expand=True)

        self._bind_events()
        self.sort_sections()

    @property
    def startTimestamp(self):
        return self._startTimestamp

    @startTimestamp.setter
    def startTimestamp(self, newVal):
        if newVal < self.MIN_TIMESTAMP:
            self._startTimestamp = self.MIN_TIMESTAMP
        elif newVal > self.MAX_TIMESTAMP:
            self._startTimestamp = self.MAX_TIMESTAMP
        else:
            self._startTimestamp = newVal
        self.draw_timeline()

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, newVal):
        if newVal < self.SCALE_MIN:
            self._scale = self.SCALE_MIN
        elif newVal > self.SCALE_MAX:
            self._scale = self.SCALE_MAX
        else:
            self._scale = newVal
        self.draw_timeline()

    @property
    def minDist(self):
        return self._minDist

    @minDist.setter
    def minDist(self, newVal):
        if newVal < self.DISTANCE_MIN:
            self._minDist = self.DISTANCE_MIN
        elif newVal > self.DISTANCE_MAX:
            self._minDist = self.DISTANCE_MAX
        else:
            self._minDist = newVal
        self.draw_timeline()

    def draw_timeline(self, event=None):
        if self._calculating:
            return

        self._calculating = True
        if self.startTimestamp is None:
            self.startTimestamp = self.firstTimestamp
        self.tlFrame.draw_timeline(
            self.startTimestamp,
            self.scale,
            self.srtSections,
            self.minDist,
            self._specificDate,
            self._dataModel.referenceDate,
        )
        self._calculating = False

    def fit_window(self):
        self.sort_sections()
        width = self.tlFrame.get_window_width() - 2 * self.PAD_X
        self.scale = (self.lastTimestamp - self.firstTimestamp) / width
        self._set_first_section()

    def get_canvas(self):
        return self.tlFrame.get_canvas()

    def go_to_first(self):
        xPos = self._set_first_section()
        self.tlFrame.draw_indicator(xPos)

    def go_to_last(self):
        xPos = self._set_last_section()
        self.tlFrame.draw_indicator(xPos)

    def go_to(self, scId):
        if scId is None:
            return

        sectionTimestamp = self._tlvCtrl.get_section_timestamp(scId)
        if sectionTimestamp is None:
            return

        xPos = self.tlFrame.get_window_width() / 2
        self.startTimestamp = sectionTimestamp - xPos * self.scale
        self.tlFrame.draw_indicator(
            xPos,
            text=self._tlvCtrl.get_section_title(scId),
        )

    def stretch_time_scale(self, event):
        deltaScale = 1.1
        if event.num == 5 or event.delta == -120:
            self.scale *= deltaScale
        if event.num == 4 or event.delta == 120:
            self.scale /= deltaScale
        return 'break'

    def adjust_cascading(self, event):
        deltaDist = 10
        if event.num == 5 or event.delta == -120:
            self.minDist += deltaDist
        if event.num == 4 or event.delta == 120:
            self.minDist -= deltaDist
        return 'break'

    def increase_scale(self):
        self.scale /= 2

    def lock(self):
        TlvSectionCanvas.isLocked = True

    def move_time_scale(self, event):
        deltaOffset = (
            self.scale
            / self.SCALE_MIN
        ) * self.tlFrame.get_scale_mark_spacing()
        if event.num == 5 or event.delta == -120:
            self.startTimestamp += deltaOffset
        if event.num == 4 or event.delta == 120:
            self.startTimestamp -= deltaOffset
        return 'break'

    def on_quit(self):
        self.tlFrame.destroy()
        self.destroy()

    def page_back(self):
        deltaX = self.tlFrame.get_window_width() * 0.9 * self.scale
        self.startTimestamp -= deltaX

    def page_forward(self):
        deltaX = self.tlFrame.get_window_width() * 0.9 * self.scale
        self.startTimestamp += deltaX

    def reduce_scale(self):
        self.scale *= 2

    def reset_casc(self):
        self.minDist = 0

    def scroll_back(self):
        deltaX = self.tlFrame.get_window_width() * 0.2 * self.scale
        self.startTimestamp -= deltaX

    def scroll_forward(self):
        deltaX = self.tlFrame.get_window_width() * 0.2 * self.scale
        self.startTimestamp += deltaX

    def set_casc_relaxed(self):
        self.minDist = self.DISTANCE_MAX

    def set_casc_tight(self):
        self.minDist = self.DISTANCE_MIN

    def set_day_scale(self):
        self.scale = (
            DAY * 2) / (
                self.SCALE_SPACING_MAX - TlvScaleCanvas.SCALE_SPACING_MIN
        )

    def set_hour_scale(self):
        self.scale = (
            HOUR * 2) / (
                self.SCALE_SPACING_MAX - TlvScaleCanvas.SCALE_SPACING_MIN
        )

    def set_year_scale(self):
        self.scale = (
            YEAR * 2) / (
                self.SCALE_SPACING_MAX - TlvScaleCanvas.SCALE_SPACING_MIN
        )

    def sort_sections(self):
        srtSections = []
        self._specificDate = False
        for scId in self._dataModel.sections:
            section = self._dataModel.sections[scId]
            if section.scType != 0:
                continue

            try:
                durationStr = get_duration_str(
                    section.lastsDays,
                    section.lastsHours,
                    section.lastsMinutes,
                )
                refIso = self._dataModel.referenceDate
                if section.time is None:
                    if not prefs.get(
                        'substitute_missing_time',
                        False
                    ):
                        continue

                    scTime = '00:00'
                else:
                    scTime = section.time

                if section.date is not None:
                    self._specificDate = True
                    scDate = section.date
                    dt = datetime.fromisoformat(f'{scDate} {scTime}')
                    weekDay = day_abbr[dt.weekday()]
                    timeStr = (
                        f"{weekDay} {self._tlvCtrl.datestr(dt)} "
                        f"{dt.hour:02}:{dt.minute:02}{durationStr}"
                    )
                elif section.day is not None:
                    if refIso is None:
                        refIso = '0001-01-01'
                        showWeekDay = False
                    else:
                        showWeekDay = True
                    scDate = get_specific_date(section.day, refIso)
                    dt = datetime.fromisoformat(f'{scDate} {scTime}')
                    if showWeekDay:
                        weekDay = f'{day_abbr[dt.weekday()]} '
                    else:
                        weekDay = ''
                    timeStr = (
                        f"{weekDay}{_('Day')} {section.day} "
                        f"{dt.hour:02}:{dt.minute:02}{durationStr}"
                    )
                else:
                    continue

                sectionColor = section.color or prefs['color_section_mark']
                srtSections.append(
                    (
                        get_timestamp(dt),
                        get_seconds(
                            section.lastsDays,
                            section.lastsHours,
                            section.lastsMinutes,
                        ),
                        section.title,
                        timeStr,
                        scId,
                        sectionColor,
                    )
                )
            except:
                pass
        self.srtSections = sorted(srtSections)
        if len(self.srtSections) > 1:
            self.firstTimestamp = self.srtSections[0][0]
            self.lastTimestamp = (
                self.srtSections[-1][0] + self.srtSections[-1][1]
            )
        else:
            self.firstTimestamp = self.MIN_TIMESTAMP
            self.lastTimestamp = self.MAX_TIMESTAMP

    def unlock(self):
        TlvSectionCanvas.isLocked = False

    def _bind_events(self):
        self._calculating = False
        self.bind('<Configure>', self.draw_timeline)

        if PLATFORM == 'win':
            event_callbacks = {
                MOUSE.BACK_CLICK: self.page_back,
                MOUSE.FORWARD_CLICK: self.page_forward,
            }
        else:
            self.bind(KEYS.QUIT_PROGRAM[0], self._tlvCtrl.on_quit)
        if PLATFORM == 'ix':
            event_callbacks = {
                MOUSE.STRETCH_TIME_SCALE_BCK: self.stretch_time_scale,
                MOUSE.STRETCH_TIME_SCALE_FWD: self.stretch_time_scale,
                MOUSE.MOVE_TIME_SCALE_BCK: self.move_time_scale,
                MOUSE.MOVE_TIME_SCALE_FWD: self.move_time_scale,
                MOUSE.ADJUST_CASCADING_BCK: self.adjust_cascading,
                MOUSE.ADJUST_CASCADING_FWD: self.adjust_cascading,
            }
        else:
            event_callbacks = {
                MOUSE.STRETCH_TIME_SCALE: self.stretch_time_scale,
                MOUSE.MOVE_TIME_SCALE: self.move_time_scale,
                MOUSE.ADJUST_CASCADING: self.adjust_cascading,
            }
        event_callbacks.update(
            {
                MOUSE.RIGHT_CLICK: self._on_right_click,
            }
        )
        for sequence, callback in event_callbacks.items():
            self.tlFrame.bind_section_canvas_event(sequence, callback)

    def _on_drag(self, event):
        deltaX = self._xPos - event.x
        self._xPos = event.x
        deltaSeconds = deltaX * self.scale
        self.startTimestamp += deltaSeconds

        deltaY = self._yPos - event.y
        self._yPos = event.y
        self.tlFrame.yview_scroll(int(deltaY), 'units')

    def _on_right_click(self, event):
        self._xPos = event.x
        self._yPos = event.y
        self.tlFrame.bind_section_canvas_event(
            MOUSE.RIGHT_RELEASE,
            self._on_right_release
        )
        self.tlFrame.config(cursor='fleur')
        self.tlFrame.bind_section_canvas_event(
            MOUSE.RIGHT_MOTION,
            self._on_drag
        )
        self.tlFrame.set_drag_scrolling()

    def _on_right_release(self, event):
        self.tlFrame.unbind_all(MOUSE.RIGHT_RELEASE)
        self.tlFrame.config(cursor='arrow')
        self.tlFrame.unbind_all(MOUSE.RIGHT_MOTION)
        self.tlFrame.set_normal_scrolling()

    def _set_first_section(self):
        xPos = self.PAD_X
        self.startTimestamp = self.firstTimestamp - xPos * self.scale
        if self.startTimestamp < self.MIN_TIMESTAMP:
            self.startTimestamp = self.MIN_TIMESTAMP
        return xPos

    def _set_last_section(self):
        xPos = self.tlFrame.get_window_width() - self.PAD_X
        self.startTimestamp = self.lastTimestamp - xPos * self.scale
        return xPos



class TlvPublicApi:

    def canUndo(self):
        if self.controlBuffer:
            return True
        else:
            return False

    def fit_window(self, event=None):
        self.view.fit_window()

    def go_to(self, scId):
        self.view.go_to(scId)

    def go_to_first(self, event=None):
        self.view.go_to_first()

    def go_to_last(self, event=None):
        self.view.go_to_last()

    def increase_scale(self, event=None):
        self.view.increase_scale()

    def lock(self, event=None):
        self.view.lock()

    def refresh(self, event=None):
        self.view.sort_sections()
        self.view.draw_timeline()

    def reset_casc(self, event=None):
        self.view.reset_casc()

    def scroll_back(self, event=None):
        self.view.scroll_back()

    def scroll_forward(self, event=None):
        self.view.scroll_forward()

    def set_casc_relaxed(self, event=None):
        self.view.set_casc_relaxed()

    def set_casc_tight(self, event=None):
        self.view.set_casc_tight

    def set_day_scale(self, event=None):
        self.view.set_day_scale()

    def set_hour_scale(self, event=None):
        self.view.set_hour_scale()

    def set_year_scale(self, event=None):
        self.view.set_year_scale()

    def undo(self, event=None):
        self.pop_section()

    def unlock(self, event=None):
        self.view.unlock()

    def page_back(self, event=None):
        self.view.page_back()

    def page_forward(self, event=None):
        self.view.page_forward()

    def reduce_scale(self, event=None):
        self.view.reduce_scale()



class TlvController(TlvPublicApi):

    def __init__(self, model, window, onDoubleClick=None):
        self._dataModel = model

        self.view = TlvMainFrame(
            self._dataModel,
            window,
            self,
        )
        self.isOpen = True
        self.firstTimestamp = None
        self.lastTimestamp = None

        self.controlBuffer = []

        self.on_double_click = onDoubleClick
        self.view.get_canvas().bind('<<double-click>>', self._on_double_click)

    def datestr(self, dt):
        if prefs.get('localize_date', True):
            return dt.strftime("%x")
        else:
            return dt.isoformat().split('T')[0]

    def get_minutes(self, pixels):
        return pixels * self.view.scale // 60

    def get_section_timestamp(self, scId):
        section = self._dataModel.sections[scId]
        if section.scType != 0:
            return

        try:
            refIso = self._dataModel.referenceDate
            if section.time is None:
                if not prefs.get('substitute_missing_time', False):
                    return

                scTime = '00:00'
            else:
                scTime = section.time

            if section.date is not None:
                scDate = section.date
            elif section.day is not None:
                if refIso is None:
                    refIso = '0001-01-01'
                scDate = get_specific_date(section.day, refIso)
            else:
                return

            return get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}'))

        except:
            return

    def get_section_id(self, event):
        return self.view.get_canvas().get_section_id(event)

    def get_section_title(self, scId):
        return self._dataModel.sections[scId].title

    def on_quit(self):
        if not self.isOpen:
            return

        self.view.on_quit()
        self.isOpen = False

    def shift_section(self, scId, pixels):
        self.push_section(scId)

        deltaSeconds = int(pixels * self.view.scale)
        section = self._dataModel.sections[scId]
        refIso = self._dataModel.referenceDate
        if section.time is None:
            scTime = '00:00'
        else:
            scTime = section.time
        if section.date is not None:
            scDate = section.date
        elif section.day is not None:
            scDate = get_specific_date(section.day, refIso)
        else:
            scDate = refIso

        timestamp = get_timestamp(
            datetime.fromisoformat(f'{scDate} {scTime}')
        ) + deltaSeconds
        dt = from_timestamp(timestamp)
        dateStr, timeStr = datetime.isoformat(dt).split('T')
        section.time = timeStr
        if section.date is not None:
            section.date = dateStr
        else:
            dayStr = get_unspecific_date(dateStr, refIso)
            section.day = dayStr

    def shift_section_end(self, scId, pixels):
        self.push_section(scId)

        deltaSeconds = int(pixels * self.view.scale)
        section = self._dataModel.sections[scId]
        seconds = get_seconds(
            section.lastsDays,
            section.lastsHours,
            section.lastsMinutes
        )
        seconds += deltaSeconds
        if seconds < 0:
            seconds = 0

        days, hours, minutes = get_duration(seconds)
        if days:
            section.lastsDays = str(days)
        else:
            section.lastsDays = None
        if hours:
            section.lastsHours = str(hours)
        else:
            section.lastsHours = None
        if minutes:
            section.lastsMinutes = str(minutes)
        else:
            section.lastsMinutes = None

    def push_section(self, scId):
        section = self._dataModel.sections[scId]
        scnData = (
            scId,
            section.date,
            section.time,
            section.day,
            section.lastsDays,
            section.lastsHours,
            section.lastsMinutes
        )
        self.controlBuffer.append(scnData)
        root = self.view.winfo_toplevel()
        root.event_generate('<<enable_undo>>')

    def pop_section(self, event=None):
        if not self.controlBuffer:
            return

        if TlvSectionCanvas.isLocked:
            return

        scnData = self.controlBuffer.pop()
        (
            scId,
            sectionDate,
            sectionTime,
            sectionDay,
            sectionLastsDays,
            sectionLastsHours,
            sectionLastsMinutes
        ) = scnData
        section = self._dataModel.sections[scId]
        section.date = sectionDate
        section.time = sectionTime
        section.day = sectionDay
        section.lastsDays = sectionLastsDays
        section.lastsHours = sectionLastsHours
        section.lastsMinutes = sectionLastsMinutes
        if not self.controlBuffer:
            root = self.view.winfo_toplevel()
            root.event_generate('<<disable_undo>>')

    def _on_double_click(self, event):
        scId = self.get_section_id(event)
        if self.on_double_click is not None:
            self.on_double_click(scId)



class TlviewMenu(tk.Menu):

    def __init__(self, master, cnf={}, **kw):
        super().__init__(master=master, cnf=cnf, **kw)

        self.goMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Go to'), menu=self.goMenu)
        self.goMenu.add_command(
            label=_('First section'),
            command=self._event('<<go_to_first>>'),
        )
        self.goMenu.add_command(
            label=_('Last section'),
            command=self._event('<<go_to_last>>'),
        )
        self.goMenu.add_command(
            label=_('Selected section'),
            command=self._event('<<go_to_selected>>'),
        )

        self.scaleMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Scale'), menu=self.scaleMenu)
        self.scaleMenu.add_command(
            label=_('Hours'),
            command=self._event('<<set_hour_scale>>'),
        )
        self.scaleMenu.add_command(
            label=_('Days'),
            command=self._event('<<set_day_scale>>'),
        )
        self.scaleMenu.add_command(
            label=_('Years'),
            command=self._event('<<set_year_scale>>'),
        )
        self.scaleMenu.add_command(
            label=_('Fit to window'),
            command=self._event('<<fit_window>>'),
        )

        self.cascadeMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Cascading'), menu=self.cascadeMenu)
        self.cascadeMenu.add_command(
            label=_('Tight'),
            command=self._event('<<set_casc_tight>>'),
        )
        self.cascadeMenu.add_command(
            label=_('Relaxed'),
            command=self._event('<<set_casc_relaxed>>'),
        )
        self.cascadeMenu.add_command(
            label=_('Standard'),
            command=self._event('<<reset_casc>>'),
        )

        self.optionsMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Options'), menu=self.optionsMenu)

        self._substituteMissingTimeVar = tk.BooleanVar(
            value=prefs['substitute_missing_time'],
        )
        self.optionsMenu.add_checkbutton(
            label=_('Use 00:00 for missing times'),
            variable=self._substituteMissingTimeVar,
            command=self._change_substitution_mode,
        )

        self._darkModeVar = tk.BooleanVar(
            value=prefs['dark_mode'],
        )
        self.optionsMenu.add_checkbutton(
            label=_('Dark mode'),
            variable=self._darkModeVar,
            command=self._change_color_mode,
        )

        self.helpMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(
            label=_('Online help'),
            command=self._event('<<open_help>>'),
        )

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback

    def _change_color_mode(self):
        prefs['dark_mode'] = self._darkModeVar.get()
        if prefs['dark_mode']:
            prefs['color_section_background'] = 'black'
            prefs['color_section_mark'] = 'white'
            prefs['color_section_title'] = 'white'
            prefs['color_scale_background'] = 'gray25'
            prefs['color_minor_scale'] = 'gray60'
            prefs['color_major_scale'] = 'white'
            prefs['color_section_date'] = 'gray60'
            prefs['color_window_mark'] = 'gray40'

        else:
            prefs['color_section_background'] = 'white'
            prefs['color_section_mark'] = 'black'
            prefs['color_section_title'] = 'black'
            prefs['color_scale_background'] = 'gray85'
            prefs['color_minor_scale'] = 'gray50'
            prefs['color_major_scale'] = 'black'
            prefs['color_section_date'] = 'gray60'
            prefs['color_window_mark'] = 'gray95'
        root = self.master.winfo_toplevel()
        root.event_generate('<<refresh_view>>')

    def _change_substitution_mode(self):
        prefs['substitute_missing_time'] = (
            self._substituteMissingTimeVar.get()
        )
        root = self.master.winfo_toplevel()
        root.event_generate('<<refresh_view>>')
from pathlib import Path
from tkinter import ttk



class TlviewToolbar(ttk.Frame):

    def __init__(self, master, largeIcons, Hovertip):
        ttk.Frame.__init__(self, master)

        if largeIcons:
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None

        self._toolbarIcons = {}
        icons = [
            'rewindLeft',
            'arrowLeft',
            'goToFirst',
            'goToLast',
            'arrowRight',
            'rewindRight',
            'goToSelected',
            'fitToWindow',
            'arrowUp',
            'arrowDown',
            'undo',
        ]
        for icon in icons:
            try:
                self._toolbarIcons[icon] = tk.PhotoImage(
                    file=f'{iconPath}/{icon}.png'
                )
            except:
                self._toolbarIcons[icon] = None

        rewindLeftButton = ttk.Button(
            self,
            text=_('Page back'),
            image=self._toolbarIcons['rewindLeft'],
            command=self._event('<<page_back>>'),
        )
        rewindLeftButton.pack(side='left')
        rewindLeftButton.image = self._toolbarIcons['rewindLeft']

        arrowLeftButton = ttk.Button(
            self,
            text=_('Scroll back'),
            image=self._toolbarIcons['arrowLeft'],
            command=self._event('<<scroll_back>>'),
        )
        arrowLeftButton.pack(side='left')
        arrowLeftButton.image = self._toolbarIcons['arrowLeft']

        goToFirstButton = ttk.Button(
            self,
            text=_('First event'),
            image=self._toolbarIcons['goToFirst'],
            command=self._event('<<go_to_first>>'),
        )
        goToFirstButton.pack(side='left')
        goToFirstButton.image = self._toolbarIcons['goToFirst']

        goToSelectedButton = ttk.Button(
            self,
            text=_('Selected section'),
            image=self._toolbarIcons['goToSelected'],
            command=self._event('<<go_to_selected>>'),
        )
        goToSelectedButton.pack(side='left')
        goToSelectedButton.image = self._toolbarIcons['goToSelected']

        goToLastButton = ttk.Button(
            self,
            text=_('Last event'),
            image=self._toolbarIcons['goToLast'],
            command=self._event('<<go_to_last>>'),
        )
        goToLastButton.pack(side='left')
        goToLastButton.image = self._toolbarIcons['goToLast']

        arrowRightButton = ttk.Button(
            self,
            text=_('Scroll forward'),
            image=self._toolbarIcons['arrowRight'],
            command=self._event('<<scroll_forward>>'),
        )
        arrowRightButton.pack(side='left')
        arrowRightButton.image = self._toolbarIcons['arrowRight']

        rewindRightButton = ttk.Button(
            self,
            text=_('Page forward'),
            image=self._toolbarIcons['rewindRight'],
            command=self._event('<<page_forward>>'),
        )
        rewindRightButton.pack(side='left')
        rewindRightButton.image = self._toolbarIcons['rewindRight']

        tk.Frame(self, bg='light gray', width=1).pack(
            side='left',
            fill='y',
            padx=6,
        )

        arrowDownButton = ttk.Button(
            self,
            text=_('Reduce scale'),
            image=self._toolbarIcons['arrowDown'],
            command=self._event('<<reduce_scale>>'),
        )
        arrowDownButton.pack(side='left')
        arrowDownButton.image = self._toolbarIcons['arrowDown']

        fitToWindowButton = ttk.Button(
            self,
            text=_('Fit to window'),
            image=self._toolbarIcons['fitToWindow'],
            command=self._event('<<fit_window>>'),
        )
        fitToWindowButton.pack(side='left')
        fitToWindowButton.image = self._toolbarIcons['fitToWindow']

        arrowUpButton = ttk.Button(
            self,
            text=_('Increase scale'),
            image=self._toolbarIcons['arrowUp'],
            command=self._event('<<increase_scale>>'),
        )
        arrowUpButton.pack(side='left')
        arrowUpButton.image = self._toolbarIcons['arrowUp']

        tk.Frame(self, bg='light gray', width=1).pack(
            side='left',
            fill='y',
            padx=6,
        )

        self.undoButton = ttk.Button(
            self,
            text=_('Undo'),
            image=self._toolbarIcons['undo'],
            command=self._event('<<undo>>'),
            state='disabled',
        )
        self.undoButton.pack(side='left')
        self.undoButton.image = self._toolbarIcons['undo']

        ttk.Button(
            self,
            text=_('Close'),
            command=self._event('<<close_view>>'),
        ).pack(side='right')

        if Hovertip is None:
            return

        Hovertip(rewindLeftButton, rewindLeftButton['text'])
        Hovertip(arrowLeftButton, arrowLeftButton['text'])
        Hovertip(goToFirstButton, goToFirstButton['text'])
        Hovertip(goToSelectedButton, goToSelectedButton['text'])
        Hovertip(goToLastButton, goToLastButton['text'])
        Hovertip(arrowRightButton, arrowRightButton['text'])
        Hovertip(rewindRightButton, rewindRightButton['text'])
        Hovertip(arrowDownButton, arrowDownButton['text'])
        Hovertip(fitToWindowButton, fitToWindowButton['text'])
        Hovertip(arrowUpButton, arrowUpButton['text'])
        Hovertip(self.undoButton, self.undoButton['text'])

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback


class TlviewService(SubController):
    INI_FILENAME = 'tlview.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        window_geometry='600x800',
        color_scale_background='gray25',
        color_major_scale='white',
        color_minor_scale='gray60',
        color_section_background='black',
        color_section_mark='white',
        color_section_title='white',
        color_section_date='gray60',
        color_indicator='lightblue',
        color_window_mark='gray40',
    )
    OPTIONS = dict(
        substitute_missing_time=False,
        dark_mode=True,
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._tlvCtrl = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        prefs.update(self.configuration.settings)
        prefs.update(self.configuration.options)

    def close_main_window(self, event=None):
        self._mdl.delete_observer(self._tlvCtrl)
        prefs['window_geometry'] = self.mainWindow.winfo_geometry()
        self._tlvCtrl.on_quit()
        self.mainWindow.destroy()

    def lock(self):
        if self._tlvCtrl:
            self._tlvCtrl.lock()
            self._disable_undo_button()

    def on_close(self):
        self.close_main_window()

    def on_quit(self):
        self._save_configuration()
        if self._tlvCtrl is None:
            return

        self.close_main_window()
        self._tlvCtrl = None

    def unlock(self):
        if self._tlvCtrl is not None:
            self._tlvCtrl.unlock()
            if self._tlvCtrl.canUndo():
                self._enable_undo_button()

    def start_viewer(self, windowTitle):
        if not self._mdl.prjFile:
            return

        if self._tlvCtrl is not None and self._tlvCtrl.isOpen:
            if self.mainWindow.state() == 'iconic':
                self.mainWindow.state('normal')
            self.mainWindow.lift()
            self.mainWindow.focus()
            return

        self.mainWindow = tk.Toplevel()
        self.mainWindow.geometry(prefs['window_geometry'])
        self.mainWindow.minsize(400, 200)
        self.mainWindow.title(f'{self._mdl.novel.title} - {windowTitle}')
        set_icon(self.mainWindow, icon='tlview', default=False)

        mainMenu = TlviewMenu(self.mainWindow)
        self.mainWindow.config(menu=mainMenu)

        largeIcons = self._ctrl.get_preferences().get('large_icons', False)
        if self._ctrl.get_preferences()['enable_hovertips']:
            Hovertip = self._mdl.nvService.new_hovertip
        else:
            Hovertip = None
        self.toolbar = TlviewToolbar(
            self.mainWindow,
            largeIcons,
            Hovertip,
        )
        self.toolbar.pack(side='bottom', fill='x', padx=5, pady=2)

        prefs['localize_date'] = self._ctrl.get_preferences().get(
            'localize_date',
            True
        )
        self._tlvCtrl = TlvController(
            self._mdl.novel,
            self.mainWindow,
            onDoubleClick=self._go_to_selected_section_in_tree,
        )
        if self._ctrl.isLocked:
            self._tlvCtrl.lock()
        self._mdl.add_observer(self._tlvCtrl)
        self._bind_events()
        self.mainWindow.lift()
        self.mainWindow.focus()
        self.mainWindow.update_idletasks()
        self.mainWindow.geometry(prefs['window_geometry'])

        self._tlvCtrl.fit_window()

    def _bind_events(self):
        self.mainWindow.protocol('WM_DELETE_WINDOW', self.close_main_window)
        event_callbacks = {
            '<<refresh_view>>': self._tlvCtrl.refresh,
            '<<go_to_first>>': self._tlvCtrl.go_to_first,
            '<<go_to_last>>': self._tlvCtrl.go_to_last,
            '<<set_hour_scale>>': self._tlvCtrl.set_hour_scale,
            '<<set_day_scale>>': self._tlvCtrl.set_day_scale,
            '<<set_year_scale>>': self._tlvCtrl.set_year_scale,
            '<<fit_window>>': self._tlvCtrl.fit_window,
            '<<set_casc_tight>>': self._tlvCtrl.set_casc_tight,
            '<<set_casc_relaxed>>': self._tlvCtrl.set_casc_relaxed,
            '<<reset_casc>>': self._tlvCtrl.reset_casc,
            '<<page_back>>': self._tlvCtrl.page_back,
            '<<page_forward>>': self._tlvCtrl.page_forward,
            '<<scroll_back>>': self._tlvCtrl.scroll_back,
            '<<scroll_forward>>': self._tlvCtrl.scroll_forward,
            '<<reduce_scale>>': self._tlvCtrl.reduce_scale,
            '<<increase_scale>>': self._tlvCtrl.increase_scale,
            '<<undo>>': self._tlvCtrl.undo,
            '<<disable_undo>>': self._disable_undo_button,
            '<<enable_undo>>': self._enable_undo_button,
            '<<close_view>>': self.close_main_window,
            '<<open_help>>': self._open_help,
            '<<go_to_selected>>': self._go_to_selected_section_in_canvas,
        }
        for sequence, callback in event_callbacks.items():
            self.mainWindow.bind(sequence, callback)

    def _disable_undo_button(self, event=None):
        self.toolbar.undoButton.config(state='disabled')

    def _enable_undo_button(self, event=None):
        self.toolbar.undoButton.config(state='normal')

    def _go_to_selected_section_in_canvas(self, event):
        scId = self._ui.selectedNode
        if scId.startswith(SECTION_PREFIX):
            self._tlvCtrl.go_to(scId)

    def _go_to_selected_section_in_tree(self, scId):
        self._ui.tv.go_to_node(scId)

    def _open_help(self, event=None):
        TlviewHelp.open_help_page()

    def _save_configuration(self):
        for keyword in prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = prefs[keyword]
        self.configuration.write()


class Plugin(PluginBase):
    VERSION = '5.11.3'
    API_VERSION = '5.55'
    DESCRIPTION = 'A timeline view'
    URL = 'https://github.com/peter88213/nv_tlview'

    FEATURE = _('Timeline view')

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.tlviewService = TlviewService(model, view, controller)
        self._icon = self._get_icon('tlview.png')


        label = self.FEATURE
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.start_viewer,
            state='disabled',
        )
        self._ui.toolsMenu.disableOnClose.append(label)

        label = _('Timeline view Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.open_help,
        )

        self._ui.toolbar.add_separator(),

        self._ui.toolbar.new_button(
            text=self.FEATURE,
            image=self._icon,
            command=self.start_viewer,
            disableOnLock=False,
        ).pack(side='left')

    def lock(self):
        self.tlviewService.lock()

    def on_close(self):
        self.tlviewService.on_close()

    def on_quit(self):
        self.tlviewService.on_quit()

    def open_help(self, event=None):
        TlviewHelp.open_help_page()

    def start_viewer(self):
        self.tlviewService.start_viewer(self.FEATURE)

    def unlock(self):
        self.tlviewService.unlock()

