"""A timeline view plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_tlview
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path

import os
import sys
import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def open_node(self):
        pass

    def unlock(self):
        pass
import gettext
import locale
import webbrowser

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_tlview', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

MAJOR_HEIGHT = 15
MINOR_HEIGHT = 30
MAJOR_WIDTH_MIN = 120
MINOR_WIDTH_MIN = 40
MAJOR_WIDTH_MAX = 480

HOUR = 3600
DAY = HOUR * 24
YEAR = DAY * 365
MONTH = DAY * 30

HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_tlview/'


def open_help(event=None):
    webbrowser.open(HELP_URL)

from tkinter import ttk


class TlButton:

    def __init__(self, view, text, icon, command):
        self._ui = view
        self._toolbarButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=text,
            image=icon,
            command=command
            )
        self._toolbarButton.pack(side='left')
        self._toolbarButton.image = icon

    def disable(self):
        self._toolbarButton.config(state='disabled')

    def enable(self):
        self._toolbarButton.config(state='normal')
from datetime import datetime
from pathlib import Path

from calendar import isleap
from datetime import date
from datetime import datetime
from datetime import timedelta


def difference_in_years(startDate, endDate):
    diffyears = endDate.year - startDate.year
    difference = endDate - startDate.replace(endDate.year)
    days_in_year = isleap(endDate.year) and 366 or 365
    years = diffyears + (difference.days + difference.seconds / 86400.0) / days_in_year
    return int(years)


def get_age(nowIso, birthDateIso, deathDateIso):
    now = datetime.fromisoformat(nowIso)
    if deathDateIso:
        deathDate = datetime.fromisoformat(deathDateIso)
        if now > deathDate:
            years = difference_in_years(deathDate, now)
            return -1 * years

    birthDate = datetime.fromisoformat(birthDateIso)
    years = difference_in_years(birthDate, now)
    return years


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)

from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

from datetime import datetime
from datetime import timedelta


def from_timestamp(ts):
    return datetime.min + timedelta(seconds=ts)


def get_timestamp(dt):
    return int((dt - datetime.min).total_seconds() + 0.5)


def get_seconds(days, hours, minutes):
    seconds = 0
    if days:
        seconds = int(days) * 24 * 3600
    if hours:
        seconds += int(hours) * 3600
    if minutes:
        seconds += int(minutes) * 60
    return seconds


def get_duration(seconds):
    minutes = seconds // 60
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    return days, hours, minutes


def get_duration_str(days, hours, minutes):
    durationStr = ''
    if days:
        durationStr = f' {days} {_("d")}'
    if hours:
        durationStr = f' {durationStr} {hours} {_("h")}'
    if minutes:
        durationStr = f' {durationStr} {minutes} {_("m")}'
    return durationStr

from calendar import day_abbr
from datetime import datetime
import platform
from tkinter import ttk

from tkinter import ttk
from _datetime import date
from calendar import day_abbr
from calendar import month_abbr



class ScaleCanvas(tk.Canvas):

    def __init__(self, controller, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._ctrl = controller
        self['background'] = 'gray25'
        self._majorScaleColor = 'white'
        self._minorScaleColor = 'gray60'
        self.majorWidth = None
        self.minorWidth = None

    def draw(self, startTimestamp, scale, specificDate, refIso):
        self.delete("all")
        if not specificDate:
            if refIso is None:
                refIso = '0001-01-01'
                showWeekDay = False
            else:
                showWeekDay = True


        resolution = HOUR
        self.majorWidth = resolution / scale
        units = 0
        while self.majorWidth < MAJOR_WIDTH_MIN:
            resolution *= 2
            if units == 0 and resolution >= DAY:
                resolution = DAY
                units = 1
            elif units == 1 and resolution >= MONTH:
                resolution = MONTH
                units = 2
            elif units == 2 and resolution >= YEAR:
                resolution = YEAR
                units = 3
            self.majorWidth = resolution / scale

        tsOffset = resolution - startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / scale
        timestamp = startTimestamp + tsOffset

        xMax = self.winfo_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                weekDay = day_abbr[dt.weekday()]
                month = month_abbr[dt.month]
                if units == 0:
                    dtStr = f"{weekDay} {self._ctrl.datestr(dt)}"
                if units == 1:
                    dtStr = f"{weekDay} {self._ctrl.datestr(dt)}"
                elif units == 2:
                    dtStr = f"{month} {dt.year}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                if showWeekDay:
                    weekDay = f'{day_abbr[dt.weekday()]} '
                else:
                    weekDay = ''
                if units == 0:
                    dtStr = f"{weekDay} {_('Day')} {day}"
                if units == 1:
                    dtStr = f"{weekDay} {_('Day')} {day}"
                elif units == 2:
                    dtStr = f"{_('Day')} {day}"
                elif units == 3:
                    dtStr = f"{_('Day')} {day}"

            self.create_line((xPos, 0), (xPos, MAJOR_HEIGHT), width=1, fill=self._majorScaleColor)
            self.create_text((xPos + 5, 2), text=dtStr, fill=self._majorScaleColor, anchor='nw')
            xPos += self.majorWidth
            timestamp += resolution


        resolution /= 4
        self.minorWidth = resolution / scale
        while self.minorWidth < MINOR_WIDTH_MIN:
            resolution *= 2
            if units == 0 and resolution >= DAY:
                resolution = DAY
            elif units == 1 and resolution >= YEAR:
                resolution = YEAR
            self.minorWidth = resolution / scale

        tsOffset = resolution - startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / scale
        timestamp = startTimestamp + tsOffset

        xMax = self.winfo_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                weekDay = day_abbr[dt.weekday()]
                month = month_abbr[dt.month]
                if units == 0:
                    dtStr = f"{dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = f"{weekDay} {dt.day}"
                elif units == 2:
                    dtStr = f"{month}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                weekDay = day_abbr[dt.weekday()]
                if units == 0:
                    dtStr = f"{dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = day
                elif units == 2:
                    dtStr = day
                elif units == 3:
                    dtStr = day

            self.create_line((xPos, MAJOR_HEIGHT), (xPos, MINOR_HEIGHT), width=1, fill=self._minorScaleColor)
            self.create_text((xPos + 5, MAJOR_HEIGHT + 1), text=dtStr, fill=self._minorScaleColor, anchor='nw')
            xPos += self.minorWidth
            timestamp += resolution

    def get_window_width(self):
        self.update()
        return self.winfo_width()


class SectionCanvas(tk.Canvas):
    EVENT_DIST_Y = 35
    LABEL_DIST_X = 10
    MARK_HALF = 5

    def __init__(self, controller, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._ctrl = controller
        self['background'] = 'black'
        self.eventMarkColor = 'red'
        self.eventTitleColor = 'white'
        self.eventDateColor = 'gray60'
        self.indicatorColor = 'lightblue'
        self.srtSections = []
        self.yMax = 0

        self._xPos = None
        self._xStart = None
        self._active_object = None
        self._indicator = None
        self._indicatorText = None

        self.bind_all('<Escape>', self._on_escape)

    def delete_indicator(self):
        self.delete(self._indicator)
        self.delete(self._indicatorText)

    def draw(self, startTimestamp, scale, srtSections, minDist):
        self.delete("all")
        self.yMax = (len(srtSections) + 2) * self.EVENT_DIST_Y
        self.configure(scrollregion=(0, 0, 0, self.yMax))
        yStart = self.EVENT_DIST_Y
        xEnd = 0
        yPos = yStart
        labelEnd = 0
        for section in srtSections:
            timestamp, durationSeconds, title, timeStr, eventId = section
            xStart = (timestamp - startTimestamp) / scale

            if xStart > labelEnd + minDist:
                yPos = yStart
                labelEnd = 0

            xEnd = (timestamp - startTimestamp + durationSeconds) / scale
            sectionMark = self.create_polygon(
                (xStart, yPos - self.MARK_HALF),
                (xStart - self.MARK_HALF, yPos),
                (xStart, yPos + self.MARK_HALF),
                (xEnd, yPos + self.MARK_HALF),
                (xEnd + self.MARK_HALF, yPos),
                (xEnd, yPos - self.MARK_HALF),
                fill=self.eventMarkColor,
                tags=eventId
                )
            self.tag_bind(sectionMark, '<Double-Button-1>', self._on_double_click)
            self.tag_bind(sectionMark, '<Shift-Button-1>', self._on_shift_click)
            self.tag_bind(sectionMark, '<Alt-Button-1>', self._on_alt_click)

            xLabel = xEnd + self.LABEL_DIST_X
            titleLabel = self.create_text((xLabel, yPos), text=title, fill=self.eventTitleColor, anchor='w')
            titleBounds = self.bbox(titleLabel)
            if titleBounds is not None:
                timeLabel = self.create_text(xLabel, titleBounds[3], text=timeStr, fill=self.eventDateColor, anchor='nw')
                timeBounds = self.bbox(timeLabel)
                labelEnd = max(titleBounds[2], timeBounds[2])
            yPos += self.EVENT_DIST_Y

    def draw_indicator(self, xPos, text=''):
        self.delete_indicator()
        self._indicator = self.create_line(
            (xPos, 0),
            (xPos, self.yMax),
            width=1,
            dash=(2, 2),
            fill=self.indicatorColor,
            )
        self._indicatorText = self.create_text(
            (xPos + 5, 5),
            text=text,
            anchor='nw',
            fill=self.indicatorColor
            )

    def _get_section_id(self, event):
        return event.widget.itemcget('current', 'tag').split(' ')[0]

    def _move_indicator(self, deltaX):
        self.move(self._indicator, deltaX, 0)
        self.move(self._indicatorText, deltaX, 0)

    def _on_alt_click(self, event):
        self._active_object = self._get_section_id(event)
        self.tag_bind(self._active_object, '<ButtonRelease-1>', self._on_alt_release)
        self.tag_bind(self._active_object, '<B1-Motion>', self._on_drag)
        __, __, x2, __ = self.bbox(self._active_object)
        self._xStart = x2 - self.MARK_HALF
        self._xPos = event.x
        self.draw_indicator(
            self._xStart,
            text=f'{_("Shift end")}: {self._ctrl.get_section_title(self._active_object)}'
            )
        self._xStart = event.x

    def _on_alt_release(self, event):
        self.tag_unbind(self._active_object, '<ButtonRelease-1>')
        self.tag_unbind(self._active_object, '<B1-Motion>')
        deltaX = event.x - self._xStart
        self._ctrl.shift_event_end(self._active_object, deltaX)
        self._active_object = None

    def _on_double_click(self, event):
        scId = self._get_section_id(event)
        self._ctrl.go_to_section(scId)

    def _on_drag(self, event):
        deltaX = event.x - self._xPos
        self._xPos = event.x
        self._move_indicator(deltaX)

    def _on_escape(self, event):
        self.unbind_all('<ButtonRelease-1>')
        self.unbind_all('<B1-Motion>')
        self.delete_indicator()
        self._active_object = None

    def _on_shift_click(self, event):
        self._active_object = self._get_section_id(event)
        self.tag_bind(self._active_object, '<ButtonRelease-1>', self._on_shift_release)
        self.tag_bind(self._active_object, '<B1-Motion>', self._on_drag)
        x1, __, __, __ = self.bbox(self._active_object)
        self._xStart = x1 + self.MARK_HALF
        self._xPos = event.x
        self.draw_indicator(
            self._xStart,
            text=f'{_("Shift start")}: {self._ctrl.get_section_title(self._active_object)}'
            )
        self._xStart = event.x

    def _on_shift_release(self, event):
        self.tag_unbind(self._active_object, '<ButtonRelease-1>')
        self.tag_unbind(self._active_object, '<B1-Motion>')
        deltaX = event.x - self._xStart
        self._ctrl.shift_event(self._active_object, deltaX)
        self._active_object = None



class TlFrame(ttk.Frame):
    SCALE_HEIGHT = MINOR_HEIGHT

    def __init__(self, parent, controller, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)

        self.scaleCanvas = ScaleCanvas(
            controller,
            self,
            height=self.SCALE_HEIGHT,
            borderwidth=0,
            highlightthickness=0
            )
        self.scaleCanvas.pack(
            anchor='n',
            fill='x',
            )

        self.sectionCanvas = SectionCanvas(
            controller,
            self,
            borderwidth=0,
            highlightthickness=0
            )
        self.sectionCanvas.configure(yscrollcommand=scrollY.set)
        self.sectionCanvas.pack(
            anchor='n',
            fill='both',
            expand=True
            )
        self.sectionCanvas.xview_moveto(0)
        self.sectionCanvas.yview_moveto(0)

        if platform.system() == 'Linux':
            self.sectionCanvas.bind("<Button-4>", self.on_mouse_wheel)
            self.sectionCanvas.bind("<Button-5>", self.on_mouse_wheel)
        else:
            self.sectionCanvas.bind("<MouseWheel>", self.on_mouse_wheel)

        self._yscrollincrement = self.sectionCanvas['yscrollincrement']

    def yview(self, *args):
        self.sectionCanvas.yview(*args)

    def xview(self, *args):
        self.sectionCanvas.xview(*args)

    def yview_scroll(self, *args):
        self.sectionCanvas.yview_scroll(*args)

    def on_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.yview_scroll(-1, "units")
            elif event.num == 5:
                self.yview_scroll(1, "units")

    def destroy(self):
        if platform.system() == 'Linux':
            self.sectionCanvas.unbind_all("<Button-4>")
            self.sectionCanvas.unbind_all("<Button-5>")
            self.sectionCanvas.unbind_all("<Control-Button-4>")
            self.sectionCanvas.unbind_all("<Control-Button-5>")
            self.sectionCanvas.unbind_all("<Shift-Button-4>")
            self.sectionCanvas.unbind_all("<Shift-Button-5>")
            self.sectionCanvas.unbind_all("<Control-Shift-Button-4>")
            self.sectionCanvas.unbind_all("<Control-Shift-Button-5>")
        else:
            self.sectionCanvas.unbind_all("<MouseWheel>")
            self.sectionCanvas.unbind_all("<Control-MouseWheel>")
            self.sectionCanvas.unbind_all("<Shift-MouseWheel>")
            self.sectionCanvas.unbind_all("<Control-Shift-MouseWheel>")
        super().destroy()

    def set_drag_scrolling(self):
        self.sectionCanvas.configure(yscrollincrement=1)

    def set_normal_scrolling(self):
        self.sectionCanvas.configure(yscrollincrement=self._yscrollincrement)



class TlView(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')
    _KEY_UNDO = ('<Control-z>', 'Ctrl-Z')

    MIN_TIMESTAMP = get_timestamp(datetime.min)
    MAX_TIMESTAMP = get_timestamp(datetime.max)

    DISTANCE_MIN = -50
    DISTANCE_MAX = 200
    PAD_X = 100

    SCALE_MIN = 10
    SCALE_MAX = YEAR * 5

    def __init__(self, model, controller, kwargs):
        self._mdl = model
        self._ctrl = controller
        self._kwargs = kwargs
        super().__init__()

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.update()

        self._skipUpdate = False
        self.isOpen = True

        self._scale = self.SCALE_MIN
        self._startTimestamp = None
        self._minDist = 0
        self._specificDate = None

        self._xPos = None
        self._yPos = None

        self.tlFrame = TlFrame(self, self._ctrl)
        self.tlFrame.pack(fill='both', expand=True, padx=2, pady=2)

        self._substituteMissingTime = self._kwargs['substitute_missing_time']

        self._bind_events()
        self._build_menu()
        self._build_toolbar()
        self.fit_window()

    @property
    def startTimestamp(self):
        return self._startTimestamp

    @startTimestamp.setter
    def startTimestamp(self, newVal):
        if newVal < self.MIN_TIMESTAMP:
            self._startTimestamp = self.MIN_TIMESTAMP
        elif newVal > self.MAX_TIMESTAMP:
            self._startTimestamp = self.MAX_TIMESTAMP
        else:
            self._startTimestamp = newVal
        self.draw_timeline()

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, newVal):
        if newVal < self.SCALE_MIN:
            self._scale = self.SCALE_MIN
        elif newVal > self.SCALE_MAX:
            self._scale = self.SCALE_MAX
        else:
            self._scale = newVal
        self.draw_timeline()

    @property
    def minDist(self):
        return self._minDist

    @minDist.setter
    def minDist(self, newVal):
        if newVal < self.DISTANCE_MIN:
            self._minDist = self.DISTANCE_MIN
        elif newVal > self.DISTANCE_MAX:
            self._minDist = self.DISTANCE_MAX
        else:
            self._minDist = newVal
        self.draw_timeline()

    def draw_timeline(self, event=None):
        if self.startTimestamp is None:
            self.startTimestamp = self.firstTimestamp
        self.tlFrame.scaleCanvas.draw(
            self.startTimestamp,
            self.scale,
            self._specificDate,
            self._mdl.novel.referenceDate
            )
        self.tlFrame.sectionCanvas.draw(
            self.startTimestamp,
            self.scale,
            self.srtSections,
            self.minDist,
            )

    def fit_window(self):
        self.sort_sections()
        width = self.tlFrame.scaleCanvas.get_window_width() - 2 * self.PAD_X
        self.scale = (self.lastTimestamp - self.firstTimestamp) / width
        self._set_first_event()

    def go_to_first(self, event=None):
        xPos = self._set_first_event()
        self.tlFrame.sectionCanvas.draw_indicator(xPos)

    def go_to_last(self, event=None):
        xPos = self._set_last_event()
        self.tlFrame.sectionCanvas.draw_indicator(xPos)

    def go_to_selected(self, event=None):
        scId = self._ctrl.get_selected_section()
        if scId is None:
            return

        sectionTimestamp = self._ctrl.get_section_timestamp(scId)
        if sectionTimestamp is None:
            return

        xPos = self.tlFrame.scaleCanvas.get_window_width() / 2
        self.startTimestamp = sectionTimestamp - xPos * self.scale
        self.tlFrame.sectionCanvas.draw_indicator(
            xPos,
            text=self._ctrl.get_section_title(scId)
            )

    def on_control_mouse_wheel(self, event):
        deltaScale = 1.1
        if event.num == 5 or event.delta == -120:
            self.scale *= deltaScale
        if event.num == 4 or event.delta == 120:
            self.scale /= deltaScale
        return 'break'

    def on_control_shift_mouse_wheel(self, event):
        deltaDist = 10
        if event.num == 5 or event.delta == -120:
            self.minDist += deltaDist
        if event.num == 4 or event.delta == 120:
            self.minDist -= deltaDist
        return 'break'

    def on_quit(self, event=None):
        self._kwargs['window_geometry'] = self.winfo_geometry()
        self.tlFrame.destroy()
        self.destroy()

    def on_shift_mouse_wheel(self, event):
        deltaOffset = self.scale / self.SCALE_MIN * self.tlFrame.scaleCanvas.majorWidth
        if event.num == 5 or event.delta == -120:
            self.startTimestamp += deltaOffset
        if event.num == 4 or event.delta == 120:
            self.startTimestamp -= deltaOffset
        return 'break'

    def refresh(self):
        if not self._skipUpdate:
            self.sort_sections()
            self.draw_timeline()

    def reset_casc(self, event=None):
        self.minDist = 0

    def set_casc_relaxed(self, event=None):
        self.minDist = self.DISTANCE_MAX

    def set_casc_tight(self, event=None):
        self.minDist = self.DISTANCE_MIN

    def set_day_scale(self, event=None):
        self.scale = (DAY * 2) / (MAJOR_WIDTH_MAX - MAJOR_WIDTH_MIN)

    def set_hour_scale(self, event=None):
        self.scale = (HOUR * 2) / (MAJOR_WIDTH_MAX - MAJOR_WIDTH_MIN)

    def set_year_scale(self, event=None):
        self.scale = (YEAR * 2) / (MAJOR_WIDTH_MAX - MAJOR_WIDTH_MIN)

    def sort_sections(self):
        srtSections = []
        self._specificDate = False
        for scId in self._mdl.novel.sections:
            section = self._mdl.novel.sections[scId]
            if section.scType != 0:
                continue

            try:
                durationStr = get_duration_str(section.lastsDays, section.lastsHours, section.lastsMinutes)
                refIso = self._mdl.novel.referenceDate
                if section.time is None:
                    if not self._substituteMissingTime:
                        continue

                    scTime = '00:00'
                else:
                    scTime = section.time

                if section.date is not None:
                    self._specificDate = True
                    scDate = section.date
                    dt = datetime.fromisoformat(f'{scDate} {scTime}')
                    weekDay = day_abbr[dt.weekday()]
                    timeStr = f"{weekDay} {self._ctrl.datestr(dt)} {dt.hour:02}:{dt.minute:02}{durationStr}"
                elif section.day is not None:
                    if refIso is None:
                        refIso = '0001-01-01'
                        showWeekDay = False
                    else:
                        showWeekDay = True
                    scDate = get_specific_date(section.day, refIso)
                    dt = datetime.fromisoformat(f'{scDate} {scTime}')
                    if showWeekDay:
                        weekDay = f'{day_abbr[dt.weekday()]} '
                    else:
                        weekDay = ''
                    timeStr = f"{weekDay}{_('Day')} {section.day} {dt.hour:02}:{dt.minute:02}{durationStr}"
                else:
                    continue

                srtSections.append(
                        (
                        get_timestamp(dt),
                        get_seconds(section.lastsDays, section.lastsHours, section.lastsMinutes),
                        section.title,
                        timeStr,
                        scId
                        )
                    )
            except:
                pass
        self.srtSections = sorted(srtSections)
        if len(self.srtSections) > 1:
            self.firstTimestamp = self.srtSections[0][0]
            self.lastTimestamp = self.srtSections[-1][0] + self.srtSections[-1][1]
        else:
            self.firstTimestamp = self.MIN_TIMESTAMP
            self.lastTimestamp = self.MAX_TIMESTAMP

    def _bind_events(self):
        self.bind('<Configure>', self.draw_timeline)
        self.bind('<F1>', open_help)
        self.bind(self._KEY_UNDO[0], self._ctrl.pop_event)
        self.protocol("WM_DELETE_WINDOW", self._ctrl.on_quit)
        if platform.system() == 'Windows':
            self.tlFrame.sectionCanvas.bind('<4>', self._page_back)
            self.tlFrame.sectionCanvas.bind('<5>', self._page_forward)
        else:
            self.bind(self._KEY_QUIT_PROGRAM[0], self._ctrl.on_quit)
        if platform.system() == 'Linux':
            self.tlFrame.sectionCanvas.bind("<Control-Button-4>", self.on_control_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Button-5>", self.on_control_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Shift-Button-5>", self.on_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Shift-Button-4>", self.on_control_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Shift-Button-5>", self.on_control_shift_mouse_wheel)
        else:
            self.tlFrame.sectionCanvas.bind("<Control-MouseWheel>", self.on_control_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
            self.tlFrame.sectionCanvas.bind("<Control-Shift-MouseWheel>", self.on_control_shift_mouse_wheel)
        self.tlFrame.bind_all('<Button-3>', self._on_right_click)

    def _build_menu(self):
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.goMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Go to'), menu=self.goMenu)
        self.goMenu.add_command(label=_('First event'), command=self.go_to_first)
        self.goMenu.add_command(label=_('Last event'), command=self.go_to_last)
        self.goMenu.add_command(label=_('Selected section'), command=self.go_to_selected)

        self._substTime = tk.BooleanVar(value=self._substituteMissingTime)

        self.scaleMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Scale'), menu=self.scaleMenu)
        self.scaleMenu.add_command(label=_('Hours'), command=self.set_hour_scale)
        self.scaleMenu.add_command(label=_('Days'), command=self.set_day_scale)
        self.scaleMenu.add_command(label=_('Years'), command=self.set_year_scale)
        self.scaleMenu.add_command(label=_('Fit to window'), command=self.fit_window)

        self.substMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Substitutions'), menu=self.substMenu)
        self.substMenu.add_checkbutton(
            label=_('Use 00:00 for missing times'),
            variable=self._substTime,
            command=self._set_substitute_missing_time
            )

        self.cascadeMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Cascading'), menu=self.cascadeMenu)
        self.cascadeMenu.add_command(label=_('Tight'), command=self.set_casc_tight)
        self.cascadeMenu.add_command(label=_('Relaxed'), command=self.set_casc_relaxed)
        self.cascadeMenu.add_command(label=_('Standard'), command=self.reset_casc)

        self.helpMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator='F1', command=open_help)

    def _build_toolbar(self):
        self.toolbar = ttk.Frame(self)
        self.toolbar.pack(fill='x', padx=5, pady=2)

        toolbarIcons = self._ctrl.get_toolbar_icons()

        rewindLeftButton = ttk.Button(
            self.toolbar,
            text=_('Page back'),
            image=toolbarIcons['rewindLeft'],
            command=self._page_back
            )
        rewindLeftButton.pack(side='left')
        rewindLeftButton.image = toolbarIcons['rewindLeft']

        arrowLeftButton = ttk.Button(
            self.toolbar,
            text=_('Scroll back'),
            image=toolbarIcons['arrowLeft'],
            command=self._scroll_back
            )
        arrowLeftButton.pack(side='left')
        arrowLeftButton.image = toolbarIcons['arrowLeft']

        goToFirstButton = ttk.Button(
            self.toolbar,
            text=_('First event'),
            image=toolbarIcons['goToFirst'],
            command=self.go_to_first
            )
        goToFirstButton.pack(side='left')
        goToFirstButton.image = toolbarIcons['goToFirst']

        goToSelectedButton = ttk.Button(
            self.toolbar,
            text=_('Selected section'),
            image=toolbarIcons['goToSelected'],
            command=self.go_to_selected
            )
        goToSelectedButton.pack(side='left')
        goToSelectedButton.image = toolbarIcons['goToSelected']

        goToLastButton = ttk.Button(
            self.toolbar,
            text=_('Last event'),
            image=toolbarIcons['goToLast'],
            command=self.go_to_last
            )
        goToLastButton.pack(side='left')
        goToLastButton.image = toolbarIcons['goToLast']

        arrowRightButton = ttk.Button(
            self.toolbar,
            text=_('Scroll forward'),
            image=toolbarIcons['arrowRight'],
            command=self._scroll_forward
            )
        arrowRightButton.pack(side='left')
        arrowRightButton.image = toolbarIcons['arrowRight']

        rewindRightButton = ttk.Button(
            self.toolbar,
            text=_('Page forward'),
            image=toolbarIcons['rewindRight'],
            command=self._page_forward
            )
        rewindRightButton.pack(side='left')
        rewindRightButton.image = toolbarIcons['rewindRight']

        tk.Frame(self.toolbar, bg='light gray', width=1).pack(side='left', fill='y', padx=6)

        arrowDownButton = ttk.Button(
            self.toolbar,
            text=_('Reduce scale'),
            image=toolbarIcons['arrowDown'],
            command=self._reduce_scale
            )
        arrowDownButton.pack(side='left')
        arrowDownButton.image = toolbarIcons['arrowDown']

        fitToWindowButton = ttk.Button(
            self.toolbar,
            text=_('Fit to window'),
            image=toolbarIcons['fitToWindow'],
            command=self.fit_window
            )
        fitToWindowButton.pack(side='left')
        fitToWindowButton.image = toolbarIcons['fitToWindow']

        arrowUpButton = ttk.Button(
            self.toolbar,
            text=_('Increase scale'),
            image=toolbarIcons['arrowUp'],
            command=self._increase_scale
            )
        arrowUpButton.pack(side='left')
        arrowUpButton.image = toolbarIcons['arrowUp']

        tk.Frame(self.toolbar, bg='light gray', width=1).pack(side='left', fill='y', padx=6)

        self.undoButton = ttk.Button(
            self.toolbar,
            text=_('Undo'),
            image=toolbarIcons['undo'],
            command=self._ctrl.pop_event,
            state='disabled',
            )
        self.undoButton.pack(side='left')
        self.undoButton.image = toolbarIcons['undo']

        ttk.Button(
            self.toolbar,
            text=_('Close'),
            command=self._ctrl.on_quit
            ).pack(side='right')

    def _increase_scale(self):
        self.scale /= 2

    def _on_drag(self, event):
        deltaX = self._xPos - event.x
        self._xPos = event.x
        deltaSeconds = deltaX * self.scale
        self.startTimestamp += deltaSeconds

        deltaY = self._yPos - event.y
        self._yPos = event.y
        self.tlFrame.yview_scroll(int(deltaY), 'units')

    def _on_right_click(self, event):
        self._xPos = event.x
        self._yPos = event.y
        self.tlFrame.bind_all('<ButtonRelease-3>', self._on_right_release)
        self.tlFrame.config(cursor='fleur')
        self.tlFrame.bind_all('<B3-Motion>', self._on_drag)
        self.tlFrame.set_drag_scrolling()

    def _on_right_release(self, event):
        self.tlFrame.unbind_all('<ButtonRelease-3>')
        self.tlFrame.config(cursor='arrow')
        self.tlFrame.unbind_all('<B3-Motion>')
        self.tlFrame.set_normal_scrolling()

    def _page_back(self, event=None):
        deltaX = self.tlFrame.scaleCanvas.get_window_width() * 0.9 * self.scale
        self.startTimestamp -= deltaX

    def _page_forward(self, event=None):
        deltaX = self.tlFrame.scaleCanvas.get_window_width() * 0.9 * self.scale
        self.startTimestamp += deltaX

    def _reduce_scale(self):
        self.scale *= 2

    def _scroll_back(self, event=None):
        deltaX = self.tlFrame.scaleCanvas.get_window_width() * 0.2 * self.scale
        self.startTimestamp -= deltaX

    def _scroll_forward(self, event=None):
        deltaX = self.tlFrame.scaleCanvas.get_window_width() * 0.2 * self.scale
        self.startTimestamp += deltaX

    def _set_first_event(self):
        xPos = self.PAD_X
        self.startTimestamp = self.firstTimestamp - xPos * self.scale
        if self.startTimestamp < self.MIN_TIMESTAMP:
            self.startTimestamp = self.MIN_TIMESTAMP
        return xPos

    def _set_last_event(self):
        xPos = self.tlFrame.scaleCanvas.get_window_width() - self.PAD_X
        self.startTimestamp = self.lastTimestamp - xPos * self.scale
        return xPos

    def _set_substitute_missing_time(self):
        self._substituteMissingTime = self._substTime.get()
        self._kwargs['substitute_missing_time'] = self._substituteMissingTime
        self.sort_sections()
        self.draw_timeline()



class TlController:

    def __init__(self, model, view, controller, kwargs):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        self.prefs = self._ctrl.get_preferences()
        if self.prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None

        self._toolbarIcons = {}
        icons = [
            'rewindLeft',
            'arrowLeft',
            'goToFirst',
            'goToLast',
            'arrowRight',
            'rewindRight',
            'goToSelected',
            'fitToWindow',
            'arrowUp',
            'arrowDown',
            'undo',
            ]
        for icon in icons:
            try:
                self._toolbarIcons[icon] = tk.PhotoImage(file=f'{iconPath}/{icon}.png')
            except:
                self._toolbarIcons[icon] = None

        self.view = TlView(self._mdl, self, kwargs)
        self._ui.register_view(self.view)
        self.isOpen = True

        self.firstTimestamp = None
        self.lastTimestamp = None

        self._kwargs = kwargs

        self._controlBuffer = []

    def datestr(self, dt):
        if self.prefs.get('localize_date', True):
            return dt.strftime("%x")
        else:
            return dt.isoformat().split('T')[0]

    def get_minutes(self, pixels):
        return pixels * self.view.scale // 60

    def get_section_timestamp(self, scId):
        section = self._mdl.novel.sections[scId]
        if section.scType != 0:
            return

        try:
            refIso = self._mdl.novel.referenceDate
            if section.time is None:
                if not self._kwargs['substitute_missing_time']:
                    return

                scTime = '00:00'
            else:
                scTime = section.time

            if section.date is not None:
                scDate = section.date
            elif section.day is not None:
                if refIso is None:
                    refIso = '0001-01-01'
                scDate = get_specific_date(section.day, refIso)
            else:
                return

            return get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}'))

        except:
            return

    def get_section_title(self, scId):
        return self._mdl.novel.sections[scId].title

    def get_selected_section(self):
        scId = self._ui.tv.tree.selection()[0]
        if scId.startswith(SECTION_PREFIX):
            return scId

    def get_toolbar_icons(self):
        return self._toolbarIcons

    def go_to_section(self, scId):
        self._ui.tv.go_to_node(scId)

    def on_quit(self):
        if not self.isOpen:
            return

        self.view.on_quit()
        self._ui.unregister_view(self.view)
        del(self.view)
        self.isOpen = False

    def open_viewer(self):
        if self.view.state() == 'iconic':
            self.view.state('normal')
        self.view.lift()
        self.view.focus()

    def shift_event(self, scId, pixels):
        self.push_event(scId)

        deltaSeconds = int(pixels * self.view.scale)
        section = self._mdl.novel.sections[scId]
        refIso = self._mdl.novel.referenceDate
        if section.time is None:
            scTime = '00:00'
        else:
            scTime = section.time
        if section.date is not None:
            scDate = section.date
        elif section.day is not None:
            scDate = get_specific_date(section.day, refIso)
        else:
            scDate = refIso

        timestamp = get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}')) + deltaSeconds
        dt = from_timestamp(timestamp)
        dateStr, timeStr = datetime.isoformat(dt).split('T')
        section.time = timeStr
        if section.date is not None:
            section.date = dateStr
        else:
            dayStr = get_unspecific_date(dateStr, refIso)
            section.day = dayStr

    def shift_event_end(self, scId, pixels):
        self.push_event(scId)

        deltaSeconds = int(pixels * self.view.scale)
        seconds = get_seconds(
            self._mdl.novel.sections[scId].lastsDays,
            self._mdl.novel.sections[scId].lastsHours,
            self._mdl.novel.sections[scId].lastsMinutes
            )
        seconds += deltaSeconds
        if seconds < 0:
            seconds = 0

        days, hours, minutes = get_duration(seconds)
        self._mdl.novel.sections[scId].lastsDays = str(days)
        self._mdl.novel.sections[scId].lastsHours = str(hours)
        self._mdl.novel.sections[scId].lastsMinutes = str(minutes)

    def push_event(self, scId, event=None):
        section = self._mdl.novel.sections[scId]
        eventData = (
            scId,
            section.date,
            section.time,
            section.day,
            section.lastsDays,
            section.lastsHours,
            section.lastsMinutes
        )
        self._controlBuffer.append(eventData)
        self.view.undoButton.config(state='normal')

    def pop_event(self, event=None):
        if not self._controlBuffer:
            return

        eventData = self._controlBuffer.pop()
        scId, sectionDate, sectionTime, sectionDay, sectionLastsDays, sectionLastsHours, sectionLastsMinutes = eventData
        section = self._mdl.novel.sections[scId]
        section.date = sectionDate
        section.time = sectionTime
        section.day = sectionDay
        section.lastsDays = sectionLastsDays
        section.lastsHours = sectionLastsHours
        section.lastsMinutes = sectionLastsMinutes
        if not self._controlBuffer:
            self.view.undoButton.config(state='disabled')


SETTINGS = dict(
    window_geometry='600x800',
)
OPTIONS = dict(
    substitute_missing_time=False,
)

APPLICATION = _('Timeline view')
PLUGIN = f'{APPLICATION} plugin v1.4.0'


class Plugin(PluginBase):
    VERSION = '1.4.0'
    API_VERSION = '4.7'
    DESCRIPTION = 'A timeline view'
    URL = 'https://github.com/peter88213/nv_tlview'

    def install(self, model, view, controller, prefs=None):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ctrl = controller
        self._ui = view
        self._tlUi = None
        self._tlCtrl = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.novx/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/tlview.ini'
        self.configuration = self._mdl.nvService.make_configuration(
            settings=SETTINGS,
            options=OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._open_viewer)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

        self._ui.helpMenu.add_command(label=_('Timeline view Online help'), command=open_help)


        prefs = controller.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
        except:
            iconPath = None
        try:
            tlIcon = tk.PhotoImage(file=f'{iconPath}/tlview.png')
        except:
            tlIcon = None

        tk.Frame(view.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._tlButton = TlButton(view, _('Timeline view'), tlIcon, self._open_viewer)

    def _open_viewer(self):
        if not self._mdl.prjFile:
            return

        if self._tlCtrl is not None and self._tlCtrl.isOpen:
            self._tlCtrl.open_viewer()
            return

        self._tlCtrl = TlController(self._mdl, self._ui, self._ctrl, self.kwargs)
        self._tlCtrl.view.title(f'{self._mdl.novel.title} - {PLUGIN}')
        set_icon(self._tlCtrl.view, icon='tLogo32', default=False)

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')
        self._tlButton.disable()

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')
        self._tlButton.enable()

    def on_close(self):
        """Actions to be performed when a project is closed.
        
        Overrides the superclass method.
        """
        self._tlCtrl.on_quit()

    def on_quit(self):
        """Actions to be performed when novelibre is closed.
        
        Overrides the superclass method.
        """
        if self._tlCtrl is None:
            return

        self._tlCtrl.on_quit()
        self._tlCtrl = None

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
