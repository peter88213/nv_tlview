[Project homepage](https://github.com/peter88213/nv_tlview) > Instructions for use

--- 

*nv_tlview* is a plugin providing a timeline view. 

---

## Download and install

### Default: Executable Python zip archive

Download the latest release [nv_tlview_v0.99.0.pyzw](https://github.com/peter88213/nv_tlview/raw/main/dist/nv_tlview_v0.99.0.pyzw)

- Launch *nv_tlview_v0.99.0.pyzw* by double-clicking (Windows/Linux desktop),
- or execute `python nv_tlview_v0.99.0.pyzw` (Windows), resp. `python3 nv_tlview_v0.99.0.pyzw` (Linux) on the command line.

#### Important

Many web browsers recognize the download as an executable file and offer to open it immediately. 
This starts the installation.

However, depending on your security settings, your browser may 
initially  refuse  to download the executable file. 
In this case, your confirmation or an additional action is required. 
If this is not possible, you have the option of downloading 
the zip file. 


### Alternative: Zip file

The package is also available in zip format: [nv_tlview_v0.99.0.zip](https://github.com/peter88213/nv_tlview/raw/main/dist/nv_tlview_v0.99.0.zip)

- Extract the *nv_tlview_v0.99.0* folder from the downloaded zipfile "nv_tlview_v0.99.0.zip".
- Move into this new folder and launch *setup.pyw* by double-clicking (Windows/Linux desktop), 
- or execute `python setup.pyw` (Windows), resp. `python3 setup.pyw` (Linux) on the command line.

---

# Operation

- Compress or expand the time scale with ``Ctrl``-``Mousewheel``.
- Move the time scale with ``Shift``-``Mousewheel``.

---

# License

This is Open Source software, and the *nv_tlview* plugin is licensed under GPLv3. See the
[GNU General Public License website](https://www.gnu.org/licenses/gpl-3.0.en.html) for more
details, or consult the [LICENSE](https://github.com/peter88213/nv_tlview/blob/main/LICENSE) file.
